import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { payments, subscriptions, users } from "../drizzle/schema";
import { InsertPayment, InsertSubscription, Subscription } from "../drizzle/schema";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

/**
 * Create or update a subscription for a user
 */
export async function upsertSubscription(
  userId: number,
  data: Omit<InsertSubscription, "userId">
): Promise<Subscription | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert subscription: database not available");
    return null;
  }

  try {
    const existing = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.userId, userId))
      .limit(1);

    if (existing.length > 0) {
      // Update existing subscription
      await db
        .update(subscriptions)
        .set(data)
        .where(eq(subscriptions.userId, userId));
      
      const updated = await db
        .select()
        .from(subscriptions)
        .where(eq(subscriptions.userId, userId))
        .limit(1);
      
      return updated[0] || null;
    } else {
      // Create new subscription
      await db.insert(subscriptions).values({
        ...data,
        userId,
      });

      const created = await db
        .select()
        .from(subscriptions)
        .where(eq(subscriptions.userId, userId))
        .limit(1);

      return created[0] || null;
    }
  } catch (error) {
    console.error("[Database] Failed to upsert subscription:", error);
    throw error;
  }
}

/**
 * Get subscription by user ID
 */
export async function getSubscriptionByUserId(userId: number): Promise<Subscription | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get subscription: database not available");
    return null;
  }

  try {
    const result = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.userId, userId))
      .limit(1);

    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get subscription:", error);
    throw error;
  }
}

/**
 * Get subscription by Stripe customer ID
 */
export async function getSubscriptionByStripeCustomerId(
  stripeCustomerId: string
): Promise<Subscription | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get subscription: database not available");
    return null;
  }

  try {
    const result = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.stripeCustomerId, stripeCustomerId))
      .limit(1);

    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get subscription by Stripe ID:", error);
    throw error;
  }
}

/**
 * Create a payment record
 */
export async function createPayment(data: InsertPayment): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create payment: database not available");
    return;
  }

  try {
    await db.insert(payments).values(data);
  } catch (error) {
    console.error("[Database] Failed to create payment:", error);
    throw error;
  }
}

/**
 * Get payment by Stripe payment intent ID
 */
export async function getPaymentByStripeId(stripePaymentIntentId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get payment: database not available");
    return null;
  }

  try {
    const result = await db
      .select()
      .from(payments)
      .where(eq(payments.stripePaymentIntentId, stripePaymentIntentId))
      .limit(1);

    return result[0] || null;
  } catch (error) {
    console.error("[Database] Failed to get payment:", error);
    throw error;
  }
}

/**
 * Update payment status
 */
export async function updatePaymentStatus(
  stripePaymentIntentId: string,
  status: string
): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update payment: database not available");
    return;
  }

  try {
    await db
      .update(payments)
      .set({ status: status as any })
      .where(eq(payments.stripePaymentIntentId, stripePaymentIntentId));
  } catch (error) {
    console.error("[Database] Failed to update payment status:", error);
    throw error;
  }
}
