import { describe, expect, it, beforeEach, vi } from "vitest";
import { PRICING_PLANS } from "./routers/stripe";

describe("Stripe Integration", () => {
  describe("Pricing Plans", () => {
    it("should have three pricing plans", () => {
      const plans = Object.keys(PRICING_PLANS);
      expect(plans).toHaveLength(3);
      expect(plans).toContain("starter");
      expect(plans).toContain("professional");
      expect(plans).toContain("enterprise");
    });

    it("should have correct pricing for Starter plan", () => {
      const plan = PRICING_PLANS.starter;
      expect(plan.price).toBe(99);
      expect(plan.interval).toBe("month");
      expect(plan.name).toBe("Starter");
    });

    it("should have correct pricing for Professional plan", () => {
      const plan = PRICING_PLANS.professional;
      expect(plan.price).toBe(249);
      expect(plan.interval).toBe("month");
      expect(plan.name).toBe("Professional");
    });

    it("should have correct pricing for Enterprise plan", () => {
      const plan = PRICING_PLANS.enterprise;
      expect(plan.price).toBe(699);
      expect(plan.interval).toBe("month");
      expect(plan.name).toBe("Enterprise");
    });

    it("should have features for each plan", () => {
      Object.values(PRICING_PLANS).forEach((plan) => {
        expect(plan.features).toBeDefined();
        expect(Array.isArray(plan.features)).toBe(true);
        expect(plan.features.length).toBeGreaterThan(0);
      });
    });

    it("should have unique feature sets for each plan", () => {
      const starterFeatures = PRICING_PLANS.starter.features;
      const professionalFeatures = PRICING_PLANS.professional.features;
      const enterpriseFeatures = PRICING_PLANS.enterprise.features;

      // Professional should have more features than Starter
      expect(professionalFeatures.length).toBeGreaterThanOrEqual(starterFeatures.length);

      // Enterprise should have more features than Professional
      expect(enterpriseFeatures.length).toBeGreaterThanOrEqual(professionalFeatures.length);
    });

    it("should have descriptions for each plan", () => {
      Object.values(PRICING_PLANS).forEach((plan) => {
        expect(plan.description).toBeDefined();
        expect(typeof plan.description).toBe("string");
        expect(plan.description.length).toBeGreaterThan(0);
      });
    });
  });

  describe("Plan Pricing Tiers", () => {
    it("should have ascending price points", () => {
      expect(PRICING_PLANS.starter.price).toBeLessThan(PRICING_PLANS.professional.price);
      expect(PRICING_PLANS.professional.price).toBeLessThan(PRICING_PLANS.enterprise.price);
    });

    it("should have reasonable price gaps", () => {
      const starterToProGap = PRICING_PLANS.professional.price - PRICING_PLANS.starter.price;
      const proToEnterprise = PRICING_PLANS.enterprise.price - PRICING_PLANS.professional.price;

      // Each tier should be at least 50% more expensive than the previous
      expect(starterToProGap).toBeGreaterThanOrEqual(PRICING_PLANS.starter.price * 0.5);
      expect(proToEnterprise).toBeGreaterThanOrEqual(PRICING_PLANS.professional.price * 0.5);
    });
  });

  describe("Plan IDs", () => {
    it("should have valid plan IDs", () => {
      const validIds = ["starter", "professional", "enterprise"];
      Object.values(PRICING_PLANS).forEach((plan) => {
        expect(validIds).toContain(plan.id);
      });
    });

    it("should have unique plan IDs", () => {
      const ids = Object.values(PRICING_PLANS).map((p) => p.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    });
  });

  describe("Plan Intervals", () => {
    it("should all be monthly billing", () => {
      Object.values(PRICING_PLANS).forEach((plan) => {
        expect(plan.interval).toBe("month");
      });
    });
  });
});
