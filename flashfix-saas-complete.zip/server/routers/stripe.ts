import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import stripe from "stripe";
import {
  upsertSubscription,
  getSubscriptionByUserId,
  createPayment,
  getPaymentByStripeId,
  updatePaymentStatus,
} from "../db-stripe";

// Initialize Stripe client only if API key is available
const stripeClient = process.env.STRIPE_SECRET_KEY
  ? new stripe(process.env.STRIPE_SECRET_KEY)
  : null;

// Pricing plans
export const PRICING_PLANS = {
  starter: {
    id: "starter",
    name: "Starter",
    price: 99,
    interval: "month" as const,
    description: "Up to 25 properties, 3 contractor seats",
    features: [
      "Up to 25 properties",
      "3 contractor seats",
      "Basic quote builder",
      "Job tracking",
      "Email support",
    ],
  },
  professional: {
    id: "professional",
    name: "Professional",
    price: 249,
    interval: "month" as const,
    description: "Up to 100 properties, unlimited contractors",
    features: [
      "Up to 100 properties",
      "Unlimited contractor seats",
      "Advanced quote builder",
      "Real-time job tracking",
      "Analytics dashboard",
      "Priority email support",
    ],
  },
  enterprise: {
    id: "enterprise",
    name: "Enterprise",
    price: 699,
    interval: "month" as const,
    description: "Unlimited properties, dedicated support",
    features: [
      "Unlimited properties",
      "Unlimited contractor seats",
      "Full API access",
      "Custom integrations",
      "White-label options",
      "Dedicated account manager",
      "24/7 phone support",
    ],
  },
};

export const stripeRouter = router({
  /**
   * Create a checkout session for subscription
   */
  createCheckoutSession: protectedProcedure
    .input(
      z.object({
        plan: z.enum(["starter", "professional", "enterprise"]),
        returnUrl: z.string().url(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        if (!stripeClient) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Stripe is not configured",
          });
        }

        const user = ctx.user;
        if (!user || !user.email) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "User must be logged in with email",
          });
        }

        const planDetails = PRICING_PLANS[input.plan];

        // Create or get Stripe customer
        let customerId: string;
        const existingCustomers = await stripeClient.customers.list({
          email: user.email,
          limit: 1,
        });

        if (existingCustomers.data.length > 0) {
          customerId = existingCustomers.data[0].id;
        } else {
          const customer = await stripeClient.customers.create({
            email: user.email,
            name: user.name || "FlashFix User",
            metadata: {
              userId: user.id.toString(),
            },
          });
          customerId = customer.id;
        }

        // Create checkout session
        const session = await stripeClient.checkout.sessions.create({
          customer: customerId,
          mode: "subscription",
          payment_method_types: ["card"],
          line_items: [
            {
              price_data: {
                currency: "usd",
                product_data: {
                  name: planDetails.name,
                  description: planDetails.description,
                },
                unit_amount: planDetails.price * 100, // Convert to cents
                recurring: {
                  interval: planDetails.interval,
                  interval_count: 1,
                },
              },
              quantity: 1,
            },
          ],
          success_url: `${input.returnUrl}?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: input.returnUrl,
          metadata: {
            userId: user.id.toString(),
            plan: input.plan,
          },
        });

        return {
          sessionId: session.id,
          url: session.url,
        };
      } catch (error) {
        console.error("[Stripe] Checkout session creation failed:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create checkout session",
        });
      }
    }),

  /**
   * Get subscription status for current user
   */
  getSubscription: protectedProcedure.query(async ({ ctx }) => {
    try {
      const subscription = await getSubscriptionByUserId(ctx.user!.id);
      return subscription || null;
    } catch (error) {
      console.error("[Stripe] Failed to get subscription:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to retrieve subscription",
      });
    }
  }),

  /**
   * Cancel subscription
   */
  cancelSubscription: protectedProcedure.mutation(async ({ ctx }) => {
    try {
      if (!stripeClient) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Stripe is not configured",
        });
      }

      const subscription = await getSubscriptionByUserId(ctx.user!.id);

      if (!subscription || !subscription.stripeSubscriptionId) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "No active subscription found",
        });
      }

      // Cancel Stripe subscription
      await stripeClient.subscriptions.cancel(subscription.stripeSubscriptionId);

      // Update database
      await upsertSubscription(ctx.user!.id, {
        status: "canceled",
        canceledAt: new Date(),
        stripeCustomerId: subscription.stripeCustomerId,
        plan: subscription.plan,
      });

      return { success: true };
    } catch (error) {
      console.error("[Stripe] Failed to cancel subscription:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to cancel subscription",
      });
    }
  }),

  /**
   * Handle Stripe webhook events
   */
  handleWebhook: publicProcedure
    .input(
      z.object({
        event: z.any(),
      })
    )
    .mutation(async ({ input }) => {
      const event = input.event;

      try {
        switch (event.type) {
          case "checkout.session.completed": {
            const session = event.data.object;
            const userId = parseInt(session.metadata.userId);
            const plan = session.metadata.plan;

            // Create subscription record
            await upsertSubscription(userId, {
              stripeCustomerId: session.customer,
              stripeSubscriptionId: session.subscription,
              plan: plan as "starter" | "professional" | "enterprise",
              status: "active",
            });
            break;
          }

          case "customer.subscription.updated": {
            const subscription = event.data.object;
            const customerId = subscription.customer;

            // Update subscription status in database
            const dbSubscription = await getSubscriptionByUserId(
              parseInt(subscription.metadata?.userId || "0")
            );

            if (dbSubscription) {
              await upsertSubscription(dbSubscription.userId, {
                stripeCustomerId: customerId,
                stripeSubscriptionId: subscription.id,
                plan: dbSubscription.plan,
                status: subscription.status,
                currentPeriodStart: new Date(subscription.current_period_start * 1000),
                currentPeriodEnd: new Date(subscription.current_period_end * 1000),
              });
            }
            break;
          }

          case "customer.subscription.deleted": {
            const subscription = event.data.object;
            const customerId = subscription.customer;

            // Mark subscription as canceled
            const dbSubscription = await getSubscriptionByUserId(
              parseInt(subscription.metadata?.userId || "0")
            );

            if (dbSubscription) {
              await upsertSubscription(dbSubscription.userId, {
                stripeCustomerId: customerId,
                stripeSubscriptionId: subscription.id,
                plan: dbSubscription.plan,
                status: "canceled",
                canceledAt: new Date(),
              });
            }
            break;
          }

          case "payment_intent.succeeded": {
            const paymentIntent = event.data.object;
            const userId = parseInt(paymentIntent.metadata?.userId || "0");

            if (userId && stripeClient) {
              const existingPayment = await getPaymentByStripeId(paymentIntent.id);

              if (!existingPayment) {
                await createPayment({
                  userId,
                  stripePaymentIntentId: paymentIntent.id,
                  amount: paymentIntent.amount,
                  currency: paymentIntent.currency,
                  status: "succeeded",
                  description: paymentIntent.description,
                });
              } else {
                await updatePaymentStatus(paymentIntent.id, "succeeded");
              }
            }
            break;
          }

          case "payment_intent.payment_failed": {
            const paymentIntent = event.data.object;
            if (stripeClient) {
              await updatePaymentStatus(paymentIntent.id, "canceled");
            }
            break;
          }
        }

        return { received: true };
      } catch (error) {
        console.error("[Stripe] Webhook processing failed:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Webhook processing failed",
        });
      }
    }),

  /**
   * Get pricing plans
   */
  getPricingPlans: publicProcedure.query(() => {
    return Object.values(PRICING_PLANS);
  }),
});
