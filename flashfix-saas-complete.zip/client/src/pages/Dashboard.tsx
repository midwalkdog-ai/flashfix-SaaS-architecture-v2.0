/**
 * FlashFix Dashboard — Role-based portal entry point
 * Design: Industrial Command Center — dark, orange accent
 * Handles: Auth gate → Admin / PM / Contractor portals
 */
import { useState } from "react";
import { useLocation } from "wouter";
import { useApp } from "@/contexts/AppContext";
import AdminPortal from "@/components/portals/AdminPortal";
import PMPortal from "@/components/portals/PMPortal";
import ContractorPortal from "@/components/portals/ContractorPortal";
import AuthGate from "@/components/AuthGate";
import AppShell from "@/components/AppShell";

export default function Dashboard() {
  const { user } = useApp();

  if (!user) {
    return <AuthGate />;
  }

  return (
    <AppShell>
      {user.role === "ADMIN" && <AdminPortal />}
      {user.role === "PROPERTY_MANAGER" && <PMPortal />}
      {user.role === "CONTRACTOR" && <ContractorPortal />}
    </AppShell>
  );
}
