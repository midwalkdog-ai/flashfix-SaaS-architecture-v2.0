import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function CheckoutSuccess() {
  const [, setLocation] = useLocation();
  const [sessionId, setSessionId] = useState<string | null>(null);

  const { data: subscription, isLoading } = trpc.stripe.getSubscription.useQuery();

  useEffect(() => {
    // Get session ID from URL
    const params = new URLSearchParams(window.location.search);
    const id = params.get("session_id");
    setSessionId(id);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <Loader2 className="animate-spin w-8 h-8" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <CheckCircle className="w-16 h-16 text-green-500" />
          </div>
          <CardTitle className="text-2xl">Payment Successful!</CardTitle>
          <CardDescription>Your subscription is now active</CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {subscription && (
            <div className="bg-slate-50 rounded-lg p-4 space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Plan:</span>
                <span className="font-semibold text-gray-900 capitalize">{subscription.plan}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Status:</span>
                <span className="font-semibold text-green-600 capitalize">{subscription.status}</span>
              </div>
              {subscription.currentPeriodEnd && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Renews:</span>
                  <span className="font-semibold text-gray-900">
                    {new Date(subscription.currentPeriodEnd).toLocaleDateString()}
                  </span>
                </div>
              )}
            </div>
          )}

          <div className="space-y-3">
            <p className="text-gray-600 text-sm">
              Your subscription is now active. You can start using all the features included in your plan.
            </p>
            <p className="text-gray-600 text-sm">
              A confirmation email has been sent to your registered email address.
            </p>
          </div>

          <div className="space-y-2">
            <Button
              onClick={() => setLocation("/dashboard")}
              className="w-full bg-orange-500 hover:bg-orange-600"
            >
              Go to Dashboard
            </Button>
            <Button
              onClick={() => setLocation("/pricing")}
              variant="outline"
              className="w-full"
            >
              Back to Pricing
            </Button>
          </div>

          <div className="border-t pt-4">
            <p className="text-xs text-gray-500 text-center">
              Session ID: {sessionId?.slice(0, 20)}...
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
