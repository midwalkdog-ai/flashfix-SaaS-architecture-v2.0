import { useLocation } from "wouter";
import { Zap, AlertTriangle } from "lucide-react";

export default function NotFound() {
  const [, navigate] = useLocation();
  return (
    <div style={{
      minHeight: '100vh', background: 'oklch(0.09 0.008 240)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      fontFamily: "'DM Sans', system-ui, sans-serif", color: 'oklch(0.94 0.005 240)',
      padding: 24,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 40 }}>
        <div style={{ width: 32, height: 32, borderRadius: 8, background: 'oklch(0.72 0.18 50)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Zap size={17} color="oklch(0.09 0.008 240)" strokeWidth={2.5} />
        </div>
        <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 18, letterSpacing: '-0.03em' }}>
          Flash<span style={{ color: 'oklch(0.72 0.18 50)' }}>Fix</span>
        </span>
      </div>
      <div style={{ width: 64, height: 64, borderRadius: 16, background: 'oklch(0.62 0.22 25 / 0.15)', border: '1px solid oklch(0.62 0.22 25 / 0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 20 }}>
        <AlertTriangle size={28} color="oklch(0.62 0.22 25)" />
      </div>
      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 56, fontWeight: 700, color: 'oklch(0.20 0.012 240)', lineHeight: 1, marginBottom: 12 }}>404</div>
      <h1 style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 22, marginBottom: 8 }}>Page not found</h1>
      <p style={{ color: 'oklch(0.60 0.015 240)', fontSize: 14, marginBottom: 28 }}>This route doesn't exist in the FlashFix platform.</p>
      <button onClick={() => navigate("/")} style={{
        background: 'oklch(0.72 0.18 50)', border: 'none', color: 'oklch(0.09 0.008 240)',
        borderRadius: 8, padding: '10px 24px', fontSize: 14, fontWeight: 700,
        cursor: 'pointer', fontFamily: "'Space Grotesk', sans-serif",
      }}>
        Back to Home
      </button>
    </div>
  );
}
