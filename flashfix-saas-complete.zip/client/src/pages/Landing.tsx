/**
 * FlashFix Landing Page — Conversion-optimized
 * Design: Industrial Command Center — dark, orange accent, Space Grotesk + DM Sans + JetBrains Mono
 * Sections: Nav, Hero, Social Proof, Features, How It Works, Pricing, Testimonials, CTA, Footer
 */
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  Zap, Building, ClipboardList, DollarSign, Users, Shield,
  CheckCircle, ArrowRight, Menu, X, Star, BarChart3,
  Camera, Clock, MapPin, TrendingUp, ChevronRight
} from "lucide-react";

const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663470771977/M5CarGemtdvJe9etXhCwP2/flashfix-hero-bg_641d52ef.jpg";
const DASHBOARD_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663470771977/M5CarGemtdvJe9etXhCwP2/flashfix-dashboard-preview_5ef9f260.jpg";
const CONTRACTOR_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663470771977/M5CarGemtdvJe9etXhCwP2/flashfix-contractor-app_9bae364a.jpg";
const TURNOVER_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663470771977/M5CarGemtdvJe9etXhCwP2/flashfix-property-turnover_729c166f.jpg";

const S = {
  // Colors
  bg: 'oklch(0.09 0.008 240)',
  bgCard: 'oklch(0.12 0.01 240)',
  bgCardHover: 'oklch(0.14 0.011 240)',
  border: 'oklch(0.20 0.012 240)',
  orange: 'oklch(0.72 0.18 50)',
  orangeLight: 'oklch(0.82 0.14 55)',
  blue: 'oklch(0.65 0.18 250)',
  green: 'oklch(0.65 0.18 155)',
  red: 'oklch(0.62 0.22 25)',
  textPrimary: 'oklch(0.94 0.005 240)',
  textSecondary: 'oklch(0.75 0.010 240)',
  textMuted: 'oklch(0.55 0.015 240)',
  // Fonts
  fontDisplay: "'Space Grotesk', system-ui, sans-serif",
  fontBody: "'DM Sans', system-ui, sans-serif",
  fontMono: "'JetBrains Mono', monospace",
};

export default function Landing() {
  const [, navigate] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  return (
    <div style={{ background: S.bg, color: S.textPrimary, fontFamily: S.fontBody, minHeight: '100vh', overflowX: 'hidden' }}>
      <Nav scrolled={scrolled} menuOpen={menuOpen} setMenuOpen={setMenuOpen} navigate={navigate} />
      <Hero navigate={navigate} />
      <SocialProof />
      <Features />
      <HowItWorks />
      <Pricing navigate={navigate} />
      <Testimonials />
      <CtaSection navigate={navigate} />
      <Footer />
    </div>
  );
}

// ── Navigation ────────────────────────────────────────────────
function Nav({ scrolled, menuOpen, setMenuOpen, navigate }: any) {
  return (
    <nav style={{
      position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
      background: scrolled ? 'oklch(0.09 0.008 240 / 0.95)' : 'transparent',
      backdropFilter: scrolled ? 'blur(12px)' : 'none',
      borderBottom: scrolled ? `1px solid ${S.border}` : '1px solid transparent',
      transition: 'all 0.3s ease',
      padding: '0 24px',
    }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', alignItems: 'center', height: 64, gap: 32 }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: S.orange, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Zap size={17} color={S.bg} strokeWidth={2.5} />
          </div>
          <span style={{ fontFamily: S.fontDisplay, fontWeight: 800, fontSize: 18, letterSpacing: '-0.03em' }}>
            Flash<span style={{ color: S.orange }}>Fix</span>
          </span>
        </div>

        {/* Desktop Nav */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 28, flex: 1 }} className="hidden lg:flex">
          {["Features", "How It Works", "Pricing"].map(item => (
            <a key={item} href={`#${item.toLowerCase().replace(/\s+/g, '-')}`} style={{
              color: S.textMuted, fontSize: 14, fontWeight: 500, textDecoration: 'none',
              transition: 'color 0.15s',
            }}
              onMouseEnter={e => e.currentTarget.style.color = S.textPrimary}
              onMouseLeave={e => e.currentTarget.style.color = S.textMuted}
            >
              {item}
            </a>
          ))}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginLeft: 'auto' }}>
          <button onClick={() => navigate("/dashboard")} style={{
            background: 'transparent', border: `1px solid ${S.border}`,
            color: S.textSecondary, borderRadius: 7, padding: '7px 16px',
            fontSize: 13, fontWeight: 500, cursor: 'pointer',
            transition: 'all 0.15s', fontFamily: S.fontBody,
          }}
            onMouseEnter={e => { e.currentTarget.style.borderColor = S.orange; e.currentTarget.style.color = S.textPrimary; }}
            onMouseLeave={e => { e.currentTarget.style.borderColor = S.border; e.currentTarget.style.color = S.textSecondary; }}
          >
            Sign In
          </button>
          <button onClick={() => navigate("/dashboard")} style={{
            background: S.orange, border: 'none',
            color: S.bg, borderRadius: 7, padding: '7px 16px',
            fontSize: 13, fontWeight: 700, cursor: 'pointer',
            fontFamily: S.fontDisplay, transition: 'all 0.15s',
          }}
            onMouseEnter={e => e.currentTarget.style.background = S.orangeLight}
            onMouseLeave={e => e.currentTarget.style.background = S.orange}
          >
            Start Free
          </button>
          {/* Mobile menu button */}
          <button onClick={() => setMenuOpen(!menuOpen)} style={{ background: 'none', border: 'none', color: S.textPrimary, cursor: 'pointer', padding: 4 }} className="flex lg:hidden">
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div style={{ background: 'oklch(0.10 0.009 240)', borderTop: `1px solid ${S.border}`, padding: '16px 24px', display: 'flex', flexDirection: 'column', gap: 12 }} className="flex lg:hidden">
          {["Features", "How It Works", "Pricing"].map(item => (
            <a key={item} href={`#${item.toLowerCase().replace(/\s+/g, '-')}`} onClick={() => setMenuOpen(false)} style={{ color: S.textSecondary, fontSize: 15, fontWeight: 500, textDecoration: 'none', padding: '8px 0' }}>
              {item}
            </a>
          ))}
          <button onClick={() => navigate("/dashboard")} style={{
            background: S.orange, border: 'none', color: S.bg,
            borderRadius: 8, padding: '12px', fontSize: 14, fontWeight: 700,
            cursor: 'pointer', fontFamily: S.fontDisplay, marginTop: 8,
          }}>
            Start Free Trial
          </button>
        </div>
      )}
    </nav>
  );
}

// ── Hero ──────────────────────────────────────────────────────
function Hero({ navigate }: any) {
  return (
    <section style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center',
      position: 'relative', overflow: 'hidden',
      paddingTop: 64,
    }}>
      {/* Background */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `url(${HERO_BG})`,
        backgroundSize: 'cover', backgroundPosition: 'center',
        opacity: 0.12,
      }} />
      <div style={{
        position: 'absolute', inset: 0,
        background: `radial-gradient(ellipse 80% 60% at 50% 40%, oklch(0.72 0.18 50 / 0.06) 0%, transparent 70%), linear-gradient(180deg, transparent 60%, ${S.bg} 100%)`,
      }} />

      {/* Grid pattern overlay */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `linear-gradient(oklch(0.94 0.005 240 / 0.03) 1px, transparent 1px), linear-gradient(90deg, oklch(0.94 0.005 240 / 0.03) 1px, transparent 1px)`,
        backgroundSize: '48px 48px',
      }} />

      <div style={{ position: 'relative', maxWidth: 1200, margin: '0 auto', padding: '80px 24px', width: '100%' }}>
        <div style={{ maxWidth: 760 }}>
          {/* Badge */}
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            background: `${S.orange.replace(')', ' / 0.12)')}`,
            border: `1px solid ${S.orange.replace(')', ' / 0.3)')}`,
            borderRadius: 20, padding: '5px 14px', marginBottom: 28,
          }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: S.orange }} />
            <span style={{ color: S.orange, fontSize: 12, fontWeight: 600, fontFamily: S.fontMono, letterSpacing: '0.04em' }}>
              PROPERTY TURNOVER PLATFORM
            </span>
          </div>

          <h1 style={{
            fontFamily: S.fontDisplay, fontWeight: 800,
            fontSize: 'clamp(36px, 6vw, 68px)',
            lineHeight: 1.05, letterSpacing: '-0.04em',
            marginBottom: 24,
          }}>
            Turn units faster.<br />
            <span style={{ color: S.orange }}>Get paid sooner.</span>
          </h1>

          <p style={{
            fontSize: 'clamp(16px, 2vw, 19px)', color: S.textSecondary,
            lineHeight: 1.6, maxWidth: 560, marginBottom: 36,
          }}>
            FlashFix connects property managers, contractors, and admins on one platform — with instant quoting, real-time job tracking, photo documentation, and a complete audit trail.
          </p>

          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 48 }}>
            <button onClick={() => navigate("/dashboard")} style={{
              background: S.orange, border: 'none', color: S.bg,
              borderRadius: 9, padding: '14px 28px',
              fontSize: 15, fontWeight: 700, cursor: 'pointer',
              fontFamily: S.fontDisplay,
              display: 'flex', alignItems: 'center', gap: 8,
              transition: 'all 0.15s',
              boxShadow: `0 4px 24px ${S.orange.replace(')', ' / 0.35)')}`,
            }}
              onMouseEnter={e => { e.currentTarget.style.background = S.orangeLight; e.currentTarget.style.transform = 'translateY(-1px)'; }}
              onMouseLeave={e => { e.currentTarget.style.background = S.orange; e.currentTarget.style.transform = 'translateY(0)'; }}
            >
              Start Free Trial <ArrowRight size={16} />
            </button>
            <button onClick={() => navigate("/dashboard")} style={{
              background: 'transparent', border: `1px solid ${S.border}`,
              color: S.textSecondary, borderRadius: 9, padding: '14px 28px',
              fontSize: 15, fontWeight: 500, cursor: 'pointer',
              fontFamily: S.fontBody, transition: 'all 0.15s',
            }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = S.orange; e.currentTarget.style.color = S.textPrimary; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = S.border; e.currentTarget.style.color = S.textSecondary; }}
            >
              View Live Demo →
            </button>
          </div>

          {/* Stats */}
          <div style={{ display: 'flex', gap: 32, flexWrap: 'wrap' }}>
            {[
              { value: "48h", label: "Avg. turnover time" },
              { value: "98%", label: "On-time completion" },
              { value: "$0", label: "Setup fee" },
            ].map(stat => (
              <div key={stat.label}>
                <div style={{ fontFamily: S.fontMono, fontSize: 24, fontWeight: 700, color: S.orange, marginBottom: 2 }}>{stat.value}</div>
                <div style={{ fontSize: 12, color: S.textMuted }}>{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Hero image */}
        <div style={{
          position: 'absolute', right: -40, top: '50%',
          transform: 'translateY(-50%)',
          width: '42%', maxWidth: 520,
          display: 'none',
        }} className="hidden xl:block">
          <div style={{
            borderRadius: 16, overflow: 'hidden',
            border: `1px solid ${S.border}`,
            boxShadow: `0 24px 80px oklch(0 0 0 / 0.5), 0 0 0 1px ${S.orange.replace(')', ' / 0.1)')}`,
          }}>
            <img src={DASHBOARD_IMG} alt="FlashFix Dashboard" style={{ width: '100%', display: 'block' }} />
          </div>
        </div>
      </div>
    </section>
  );
}

// ── Social Proof ──────────────────────────────────────────────
function SocialProof() {
  const logos = ["Greystar", "AIMCO", "Equity Residential", "Camden", "UDR", "NexPoint"];
  return (
    <section style={{ padding: '40px 24px', borderTop: `1px solid ${S.border}`, borderBottom: `1px solid ${S.border}` }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <p style={{ textAlign: 'center', fontSize: 12, color: S.textMuted, fontFamily: S.fontMono, letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 24 }}>
          Trusted by property management companies
        </p>
        <div style={{ display: 'flex', gap: 40, justifyContent: 'center', flexWrap: 'wrap', alignItems: 'center' }}>
          {logos.map(logo => (
            <span key={logo} style={{ fontFamily: S.fontDisplay, fontWeight: 700, fontSize: 15, color: S.textMuted, letterSpacing: '-0.02em', opacity: 0.6 }}>
              {logo}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Features ──────────────────────────────────────────────────
const FEATURES = [
  {
    icon: <DollarSign size={20} />,
    color: 'oklch(0.72 0.18 50)',
    title: "Instant Quote Builder",
    desc: "Build accurate quotes in under 2 minutes from a pre-loaded pricing catalog. Send for approval with one click.",
  },
  {
    icon: <ClipboardList size={20} />,
    color: 'oklch(0.65 0.18 250)',
    title: "Real-Time Job Tracking",
    desc: "Watch jobs progress in real time. Task-level checklists, completion percentages, and live status updates.",
  },
  {
    icon: <Camera size={20} />,
    color: 'oklch(0.65 0.18 155)',
    title: "Photo Documentation",
    desc: "Contractors capture before/after photos on-site. Every photo is timestamped and attached to the job record.",
  },
  {
    icon: <Shield size={20} />,
    color: 'oklch(0.72 0.18 50)',
    title: "Immutable Audit Log",
    desc: "Every action is recorded with actor, timestamp, and detail. Full accountability with no edits or deletions.",
  },
  {
    icon: <Users size={20} />,
    color: 'oklch(0.65 0.18 250)',
    title: "Role-Based Portals",
    desc: "Separate, purpose-built interfaces for Admins, Property Managers, and Contractors. Everyone sees exactly what they need.",
  },
  {
    icon: <BarChart3 size={20} />,
    color: 'oklch(0.65 0.18 155)',
    title: "Portfolio Analytics",
    desc: "Track property readiness scores, revenue per job, completion rates, and turnover velocity across your entire portfolio.",
  },
];

function Features() {
  return (
    <section id="features" style={{ padding: '100px 24px' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 64 }}>
          <div style={{ color: S.orange, fontSize: 11, fontFamily: S.fontMono, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 12 }}>
            Platform Features
          </div>
          <h2 style={{ fontFamily: S.fontDisplay, fontWeight: 800, fontSize: 'clamp(28px, 4vw, 44px)', letterSpacing: '-0.03em', marginBottom: 16 }}>
            Everything you need to run<br />a tight operation
          </h2>
          <p style={{ color: S.textSecondary, fontSize: 16, maxWidth: 520, margin: '0 auto' }}>
            From quote to completion, FlashFix handles the entire turnover workflow — so your team can focus on execution.
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 20 }}>
          {FEATURES.map(f => (
            <div key={f.title} style={{
              background: S.bgCard, border: `1px solid ${S.border}`,
              borderRadius: 14, padding: '24px',
              transition: 'all 0.2s ease',
              cursor: 'default',
            }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = f.color.replace(')', ' / 0.3)');
                e.currentTarget.style.boxShadow = `0 8px 32px ${f.color.replace(')', ' / 0.08)')}`;
                e.currentTarget.style.transform = 'translateY(-2px)';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = S.border;
                e.currentTarget.style.boxShadow = 'none';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              <div style={{
                width: 44, height: 44, borderRadius: 11,
                background: `${f.color.replace(')', ' / 0.15)')}`,
                border: `1px solid ${f.color.replace(')', ' / 0.25)')}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: f.color, marginBottom: 16,
              }}>
                {f.icon}
              </div>
              <h3 style={{ fontFamily: S.fontDisplay, fontWeight: 700, fontSize: 16, marginBottom: 8 }}>{f.title}</h3>
              <p style={{ color: S.textSecondary, fontSize: 14, lineHeight: 1.6 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── How It Works ──────────────────────────────────────────────
function HowItWorks() {
  const steps = [
    {
      num: "01",
      title: "Property Manager builds a quote",
      desc: "Select services from the pricing catalog, assign to a contractor, and submit for approval in minutes.",
      img: TURNOVER_IMG,
    },
    {
      num: "02",
      title: "Contractor executes on-site",
      desc: "The contractor receives the job on their mobile app, completes tasks, and captures photos as proof of work.",
      img: CONTRACTOR_IMG,
    },
    {
      num: "03",
      title: "Admin reviews and closes",
      desc: "Full audit trail, photo documentation, and job completion report — unit is rent-ready and revenue is recorded.",
      img: DASHBOARD_IMG,
    },
  ];

  return (
    <section id="how-it-works" style={{ padding: '100px 24px', background: 'oklch(0.10 0.009 240)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 64 }}>
          <div style={{ color: S.orange, fontSize: 11, fontFamily: S.fontMono, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 12 }}>
            How It Works
          </div>
          <h2 style={{ fontFamily: S.fontDisplay, fontWeight: 800, fontSize: 'clamp(28px, 4vw, 44px)', letterSpacing: '-0.03em' }}>
            From vacant to rent-ready<br />in three steps
          </h2>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 60 }}>
          {steps.map((step, i) => (
            <div key={step.num} style={{
              display: 'grid',
              gridTemplateColumns: i % 2 === 0 ? '1fr 1fr' : '1fr 1fr',
              gap: 48, alignItems: 'center',
            }}>
              <div style={{ order: i % 2 === 0 ? 0 : 1 }}>
                <div style={{ fontFamily: S.fontMono, fontSize: 48, fontWeight: 700, color: S.orange, opacity: 0.2, lineHeight: 1, marginBottom: 12 }}>
                  {step.num}
                </div>
                <h3 style={{ fontFamily: S.fontDisplay, fontWeight: 700, fontSize: 22, letterSpacing: '-0.02em', marginBottom: 12 }}>
                  {step.title}
                </h3>
                <p style={{ color: S.textSecondary, fontSize: 15, lineHeight: 1.7 }}>{step.desc}</p>
              </div>
              <div style={{ order: i % 2 === 0 ? 1 : 0 }}>
                <div style={{
                  borderRadius: 14, overflow: 'hidden',
                  border: `1px solid ${S.border}`,
                  boxShadow: `0 16px 48px oklch(0 0 0 / 0.4)`,
                }}>
                  <img src={step.img} alt={step.title} style={{ width: '100%', display: 'block', aspectRatio: '16/9', objectFit: 'cover' }} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Pricing ───────────────────────────────────────────────────
const PLANS = [
  {
    name: "Starter",
    price: 99,
    period: "/mo",
    desc: "For small portfolios getting started with digital turnover management.",
    color: S.blue,
    features: [
      "Up to 25 properties",
      "3 contractor seats",
      "Quote builder",
      "Job tracking & checklists",
      "Photo documentation",
      "Basic reporting",
    ],
    cta: "Start Free Trial",
  },
  {
    name: "Professional",
    price: 249,
    period: "/mo",
    desc: "For growing portfolios that need full visibility and team management.",
    color: S.orange,
    popular: true,
    features: [
      "Up to 100 properties",
      "Unlimited contractor seats",
      "Everything in Starter",
      "Audit log & compliance",
      "Advanced analytics",
      "Priority support",
      "Custom pricing catalog",
    ],
    cta: "Start Free Trial",
  },
  {
    name: "Enterprise",
    price: 699,
    period: "/mo",
    desc: "For large operators with complex multi-site portfolios and custom needs.",
    color: S.green,
    features: [
      "Unlimited properties",
      "Unlimited users",
      "Everything in Professional",
      "Dedicated account manager",
      "Custom integrations",
      "SLA guarantees",
      "White-label option",
    ],
    cta: "Contact Sales",
  },
];

function Pricing({ navigate }: any) {
  return (
    <section id="pricing" style={{ padding: '100px 24px' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 64 }}>
          <div style={{ color: S.orange, fontSize: 11, fontFamily: S.fontMono, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 12 }}>
            Pricing
          </div>
          <h2 style={{ fontFamily: S.fontDisplay, fontWeight: 800, fontSize: 'clamp(28px, 4vw, 44px)', letterSpacing: '-0.03em', marginBottom: 16 }}>
            Simple, transparent pricing
          </h2>
          <p style={{ color: S.textSecondary, fontSize: 16 }}>14-day free trial. No credit card required.</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 20 }}>
          {PLANS.map(plan => (
            <div key={plan.name} style={{
              background: plan.popular ? `${plan.color.replace(')', ' / 0.06)')}` : S.bgCard,
              border: `1px solid ${plan.popular ? plan.color.replace(')', ' / 0.4)') : S.border}`,
              borderRadius: 16, padding: '28px',
              position: 'relative',
              boxShadow: plan.popular ? `0 8px 40px ${plan.color.replace(')', ' / 0.15)')}` : 'none',
            }}>
              {plan.popular && (
                <div style={{
                  position: 'absolute', top: -12, left: '50%', transform: 'translateX(-50%)',
                  background: plan.color, color: S.bg,
                  fontSize: 10, fontWeight: 700, fontFamily: S.fontMono,
                  padding: '3px 12px', borderRadius: 10, letterSpacing: '0.06em',
                  textTransform: 'uppercase', whiteSpace: 'nowrap',
                }}>
                  Most Popular
                </div>
              )}

              <div style={{ marginBottom: 20 }}>
                <div style={{ fontFamily: S.fontDisplay, fontWeight: 700, fontSize: 18, marginBottom: 4 }}>{plan.name}</div>
                <div style={{ color: S.textMuted, fontSize: 13, lineHeight: 1.5 }}>{plan.desc}</div>
              </div>

              <div style={{ marginBottom: 24 }}>
                <span style={{ fontFamily: S.fontMono, fontSize: 40, fontWeight: 700, color: plan.color }}>${plan.price}</span>
                <span style={{ color: S.textMuted, fontSize: 14 }}>{plan.period}</span>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 28 }}>
                {plan.features.map(f => (
                  <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <CheckCircle size={14} color={plan.color} />
                    <span style={{ fontSize: 13, color: S.textSecondary }}>{f}</span>
                  </div>
                ))}
              </div>

              <button onClick={() => navigate("/dashboard")} style={{
                width: '100%', padding: '12px',
                background: plan.popular ? plan.color : 'transparent',
                border: plan.popular ? 'none' : `1px solid ${plan.color.replace(')', ' / 0.5)')}`,
                color: plan.popular ? S.bg : plan.color,
                borderRadius: 9, fontFamily: S.fontDisplay,
                fontWeight: 700, fontSize: 14, cursor: 'pointer',
                transition: 'all 0.15s',
              }}
                onMouseEnter={e => {
                  if (!plan.popular) {
                    e.currentTarget.style.background = `${plan.color.replace(')', ' / 0.1)')}`;
                  }
                }}
                onMouseLeave={e => {
                  if (!plan.popular) {
                    e.currentTarget.style.background = 'transparent';
                  }
                }}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── Testimonials ──────────────────────────────────────────────
const TESTIMONIALS = [
  {
    name: "Marcus Webb",
    title: "Director of Operations, Summit Properties",
    quote: "We cut our average turnover time from 7 days to under 48 hours. FlashFix paid for itself in the first month.",
    rating: 5,
    avatar: "MW",
    color: S.orange,
  },
  {
    name: "Priya Nair",
    title: "Property Manager, Apex Residential",
    quote: "The quote builder alone saves me 3 hours a week. I can price a full turnover in under 2 minutes and send it for approval instantly.",
    rating: 5,
    avatar: "PN",
    color: S.blue,
  },
  {
    name: "Carlos Mendez",
    title: "Lead Contractor, FastTurn Services",
    quote: "The mobile app is clean and fast. I know exactly what I need to do at each property, and the photo upload keeps everyone accountable.",
    rating: 5,
    avatar: "CM",
    color: S.green,
  },
];

function Testimonials() {
  return (
    <section style={{ padding: '100px 24px', background: 'oklch(0.10 0.009 240)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 56 }}>
          <h2 style={{ fontFamily: S.fontDisplay, fontWeight: 800, fontSize: 'clamp(24px, 3.5vw, 38px)', letterSpacing: '-0.03em' }}>
            Trusted by operators who move fast
          </h2>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 20 }}>
          {TESTIMONIALS.map(t => (
            <div key={t.name} style={{
              background: S.bgCard, border: `1px solid ${S.border}`,
              borderRadius: 14, padding: '24px',
            }}>
              <div style={{ display: 'flex', gap: 4, marginBottom: 16 }}>
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} size={14} fill={S.orange} color={S.orange} />
                ))}
              </div>
              <p style={{ color: S.textSecondary, fontSize: 14, lineHeight: 1.7, marginBottom: 20, fontStyle: 'italic' }}>
                "{t.quote}"
              </p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{
                  width: 36, height: 36, borderRadius: '50%',
                  background: `${t.color.replace(')', ' / 0.2)')}`,
                  border: `2px solid ${t.color.replace(')', ' / 0.4)')}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontWeight: 700, color: t.color,
                  fontFamily: S.fontMono,
                }}>
                  {t.avatar}
                </div>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{t.name}</div>
                  <div style={{ color: S.textMuted, fontSize: 11 }}>{t.title}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ── CTA Section ───────────────────────────────────────────────
function CtaSection({ navigate }: any) {
  return (
    <section style={{ padding: '100px 24px' }}>
      <div style={{ maxWidth: 800, margin: '0 auto', textAlign: 'center' }}>
        <div style={{
          background: `radial-gradient(ellipse 80% 60% at 50% 50%, ${S.orange.replace(')', ' / 0.08)')} 0%, transparent 70%)`,
          border: `1px solid ${S.border}`,
          borderRadius: 20, padding: '64px 40px',
        }}>
          <div style={{ color: S.orange, fontSize: 11, fontFamily: S.fontMono, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 16 }}>
            Get Started Today
          </div>
          <h2 style={{ fontFamily: S.fontDisplay, fontWeight: 800, fontSize: 'clamp(28px, 4vw, 44px)', letterSpacing: '-0.03em', marginBottom: 16 }}>
            Ready to run a tighter operation?
          </h2>
          <p style={{ color: S.textSecondary, fontSize: 16, marginBottom: 36, lineHeight: 1.6 }}>
            Join property management companies that use FlashFix to cut turnover time, reduce errors, and increase revenue per unit.
          </p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button onClick={() => navigate("/dashboard")} style={{
              background: S.orange, border: 'none', color: S.bg,
              borderRadius: 9, padding: '14px 32px',
              fontSize: 15, fontWeight: 700, cursor: 'pointer',
              fontFamily: S.fontDisplay,
              display: 'flex', alignItems: 'center', gap: 8,
              boxShadow: `0 4px 24px ${S.orange.replace(')', ' / 0.35)')}`,
              transition: 'all 0.15s',
            }}
              onMouseEnter={e => e.currentTarget.style.background = S.orangeLight}
              onMouseLeave={e => e.currentTarget.style.background = S.orange}
            >
              Start Free Trial — No Card Required <ArrowRight size={16} />
            </button>
          </div>
          <p style={{ color: S.textMuted, fontSize: 12, marginTop: 16 }}>14-day free trial · No credit card · Cancel anytime</p>
        </div>
      </div>
    </section>
  );
}

// ── Footer ────────────────────────────────────────────────────
function Footer() {
  return (
    <footer style={{ borderTop: `1px solid ${S.border}`, padding: '48px 24px' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 40, marginBottom: 48 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <div style={{ width: 28, height: 28, borderRadius: 7, background: S.orange, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Zap size={15} color={S.bg} strokeWidth={2.5} />
              </div>
              <span style={{ fontFamily: S.fontDisplay, fontWeight: 800, fontSize: 16, letterSpacing: '-0.03em' }}>
                Flash<span style={{ color: S.orange }}>Fix</span>
              </span>
            </div>
            <p style={{ color: S.textMuted, fontSize: 13, lineHeight: 1.6 }}>
              The all-in-one property turnover platform for modern operators.
            </p>
          </div>

          {[
            { title: "Product", links: ["Features", "Pricing", "Changelog", "Roadmap"] },
            { title: "Company", links: ["About", "Blog", "Careers", "Contact"] },
            { title: "Legal", links: ["Privacy Policy", "Terms of Service", "Security"] },
          ].map(col => (
            <div key={col.title}>
              <div style={{ fontFamily: S.fontDisplay, fontWeight: 700, fontSize: 13, marginBottom: 12 }}>{col.title}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {col.links.map(link => (
                  <a key={link} href="#" style={{ color: S.textMuted, fontSize: 13, textDecoration: 'none', transition: 'color 0.15s' }}
                    onMouseEnter={e => e.currentTarget.style.color = S.textPrimary}
                    onMouseLeave={e => e.currentTarget.style.color = S.textMuted}
                  >
                    {link}
                  </a>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div style={{ borderTop: `1px solid ${S.border}`, paddingTop: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
          <span style={{ color: S.textMuted, fontSize: 12, fontFamily: S.fontMono }}>
            © 2026 FlashFix Property Services LLC. All rights reserved.
          </span>
          <span style={{ color: S.textMuted, fontSize: 12 }}>
            Built for operators who move fast.
          </span>
        </div>
      </div>
    </footer>
  );
}
