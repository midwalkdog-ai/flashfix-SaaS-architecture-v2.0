/**
 * FlashFix AuthGate — Role selection / login screen
 * Design: Industrial Command Center — dark, orange accent
 */
import { useState } from "react";
import { useLocation } from "wouter";
import { useApp } from "@/contexts/AppContext";
import { Zap, Shield, Building, Hammer, ChevronRight, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

const ROLES = [
  {
    key: "admin" as const,
    label: "Platform Admin",
    subtitle: "Full system access",
    icon: <Shield size={22} />,
    color: "oklch(0.72 0.18 50)",
    desc: "Manage users, pricing catalog, audit logs, and platform-wide oversight.",
    badge: "ADMIN",
  },
  {
    key: "pm" as const,
    label: "Property Manager",
    subtitle: "Portfolio management",
    icon: <Building size={22} />,
    color: "oklch(0.65 0.18 250)",
    desc: "Manage your properties, build quotes, track jobs, and view reports.",
    badge: "PM",
  },
  {
    key: "contractor" as const,
    label: "Contractor",
    subtitle: "Field operations",
    icon: <Hammer size={22} />,
    color: "oklch(0.65 0.18 155)",
    desc: "View assigned jobs, complete tasks, and upload photo documentation.",
    badge: "FIELD",
  },
];

export default function AuthGate() {
  const { login } = useApp();
  const [, navigate] = useLocation();
  const [hovering, setHovering] = useState<string | null>(null);
  const [loading, setLoading] = useState<string | null>(null);

  const handleLogin = async (role: "admin" | "pm" | "contractor") => {
    setLoading(role);
    await new Promise(r => setTimeout(r, 600));
    login(role);
    const names = { admin: "Jordan Blake", pm: "Sarah Chen", contractor: "Mike Torres" };
    toast.success(`Welcome back, ${names[role]}`, { description: "Signed in successfully" });
    setLoading(null);
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'oklch(0.09 0.008 240)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: '24px',
      fontFamily: "'DM Sans', system-ui, sans-serif",
    }}>
      {/* Back to landing */}
      <button onClick={() => navigate("/")} style={{
        position: 'fixed', top: 20, left: 20,
        background: 'oklch(0.12 0.01 240)',
        border: '1px solid oklch(0.20 0.012 240)',
        color: 'oklch(0.60 0.015 240)',
        borderRadius: 8, padding: '8px 14px',
        fontSize: 13, cursor: 'pointer',
        display: 'flex', alignItems: 'center', gap: 6,
        transition: 'all 0.15s',
      }}
        onMouseEnter={e => { e.currentTarget.style.color = 'oklch(0.94 0.005 240)'; }}
        onMouseLeave={e => { e.currentTarget.style.color = 'oklch(0.60 0.015 240)'; }}
      >
        <ArrowLeft size={14} /> Back
      </button>

      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 40 }}>
        <div style={{
          width: 40, height: 40, borderRadius: 10,
          background: 'oklch(0.72 0.18 50)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <Zap size={22} color="oklch(0.09 0.008 240)" strokeWidth={2.5} />
        </div>
        <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 22, letterSpacing: '-0.03em', color: 'oklch(0.94 0.005 240)' }}>
          Flash<span style={{ color: 'oklch(0.72 0.18 50)' }}>Fix</span>
        </span>
      </div>

      <div style={{ textAlign: 'center', marginBottom: 40 }}>
        <h1 style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 28, letterSpacing: '-0.03em', marginBottom: 8, color: 'oklch(0.94 0.005 240)' }}>
          Sign in to your portal
        </h1>
        <p style={{ color: 'oklch(0.60 0.015 240)', fontSize: 14 }}>
          Select your role to access the demo platform
        </p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, width: '100%', maxWidth: 440 }}>
        {ROLES.map(role => {
          const isHovered = hovering === role.key;
          const isLoading = loading === role.key;
          return (
            <button
              key={role.key}
              onClick={() => handleLogin(role.key)}
              onMouseEnter={() => setHovering(role.key)}
              onMouseLeave={() => setHovering(null)}
              disabled={!!loading}
              style={{
                background: isHovered ? 'oklch(0.15 0.012 240)' : 'oklch(0.12 0.01 240)',
                border: isHovered ? `1px solid ${role.color.replace(')', ' / 0.4)')}` : '1px solid oklch(0.20 0.012 240)',
                borderLeft: isHovered ? `3px solid ${role.color}` : '1px solid oklch(0.20 0.012 240)',
                borderRadius: 12, padding: '20px 20px',
                display: 'flex', alignItems: 'center', gap: 16,
                cursor: 'pointer', textAlign: 'left',
                transition: 'all 0.15s ease',
                boxShadow: isHovered ? `0 4px 20px ${role.color.replace(')', ' / 0.1)')}` : 'none',
              }}
            >
              <div style={{
                width: 48, height: 48, borderRadius: 12,
                background: `${role.color.replace(')', ' / 0.15)')}`,
                border: `1px solid ${role.color.replace(')', ' / 0.25)')}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: role.color, flexShrink: 0,
                transition: 'all 0.15s',
              }}>
                {isLoading ? (
                  <div style={{
                    width: 18, height: 18, border: `2px solid ${role.color}`,
                    borderTopColor: 'transparent', borderRadius: '50%',
                    animation: 'spin 0.6s linear infinite',
                  }} />
                ) : role.icon}
              </div>

              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
                  <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 15, color: 'oklch(0.94 0.005 240)' }}>
                    {role.label}
                  </span>
                  <span style={{
                    background: `${role.color.replace(')', ' / 0.15)')}`,
                    color: role.color,
                    border: `1px solid ${role.color.replace(')', ' / 0.3)')}`,
                    fontSize: 10, fontWeight: 700, letterSpacing: '0.08em',
                    padding: '1px 6px', borderRadius: 3,
                    fontFamily: "'JetBrains Mono', monospace",
                    textTransform: 'uppercase',
                  }}>
                    {role.badge}
                  </span>
                </div>
                <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 12 }}>{role.desc}</div>
              </div>

              <ChevronRight size={16} color={isHovered ? role.color : 'oklch(0.40 0.010 240)'} style={{ transition: 'color 0.15s', flexShrink: 0 }} />
            </button>
          );
        })}
      </div>

      <p style={{ color: 'oklch(0.40 0.010 240)', fontSize: 12, marginTop: 32, textAlign: 'center' }}>
        This is a live demo. No account required.
      </p>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
