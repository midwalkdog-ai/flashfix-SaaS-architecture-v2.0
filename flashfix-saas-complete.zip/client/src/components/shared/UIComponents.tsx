/**
 * FlashFix Shared UI Components
 * Design: Industrial Command Center — dark, orange accent
 */
import { ReactNode } from "react";
import { JobStatus, PropertyStatus, Priority } from "@/contexts/AppContext";

// ── Status Badge ──────────────────────────────────────────────
const STATUS_CONFIG: Record<string, { label: string; className: string }> = {
  NEEDS_TURNOVER: { label: "Needs Turnover", className: "ff-badge-red" },
  IN_PROGRESS: { label: "In Progress", className: "ff-badge-yellow" },
  RENT_READY: { label: "Rent Ready", className: "ff-badge-green" },
  OCCUPIED: { label: "Occupied", className: "ff-badge-blue" },
  SCHEDULED: { label: "Scheduled", className: "ff-badge-blue" },
  COMPLETED: { label: "Completed", className: "ff-badge-green" },
  CANCELLED: { label: "Cancelled", className: "ff-badge-red" },
  HIGH: { label: "High", className: "ff-badge-red" },
  URGENT: { label: "Urgent", className: "ff-badge-red" },
  NORMAL: { label: "Normal", className: "ff-badge-blue" },
  LOW: { label: "Low", className: "ff-badge-green" },
};

export function StatusBadge({ status }: { status: string }) {
  const cfg = STATUS_CONFIG[status] || { label: status, className: "ff-badge-blue" };
  return <span className={cfg.className}>{cfg.label}</span>;
}

// ── Stat Card ─────────────────────────────────────────────────
interface StatCardProps {
  icon: ReactNode;
  label: string;
  value: string | number;
  color: string;
  trend?: string;
  trendUp?: boolean;
}

export function StatCard({ icon, label, value, color, trend, trendUp }: StatCardProps) {
  return (
    <div className="ff-stat-card">
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <div style={{
          width: 36, height: 36, borderRadius: 8,
          background: `${color.replace(')', ' / 0.15)')}`,
          border: `1px solid ${color.replace(')', ' / 0.25)')}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color,
        }}>
          {icon}
        </div>
        {trend && (
          <span style={{
            fontSize: 11, color: trendUp !== false ? 'oklch(0.65 0.18 155)' : 'oklch(0.62 0.22 25)',
            fontFamily: "'JetBrains Mono', monospace",
          }}>
            {trend}
          </span>
        )}
      </div>
      <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 24, fontWeight: 700, color, marginBottom: 4 }}>
        {value}
      </div>
      <div style={{ fontSize: 12, color: 'oklch(0.60 0.015 240)' }}>{label}</div>
    </div>
  );
}

// ── Section Header ────────────────────────────────────────────
export function SectionHeader({
  title, subtitle, action, tag
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
  tag?: string;
}) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 20, gap: 16 }}>
      <div>
        {tag && (
          <div style={{
            color: 'oklch(0.72 0.18 50)', fontSize: 10,
            fontFamily: "'JetBrains Mono', monospace", fontWeight: 700,
            letterSpacing: '0.1em', textTransform: 'uppercase', marginBottom: 4,
          }}>
            {tag}
          </div>
        )}
        <h2 style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 18, letterSpacing: '-0.02em', color: 'oklch(0.94 0.005 240)', marginBottom: subtitle ? 4 : 0 }}>
          {title}
        </h2>
        {subtitle && (
          <p style={{ color: 'oklch(0.60 0.015 240)', fontSize: 13 }}>{subtitle}</p>
        )}
      </div>
      {action && <div style={{ flexShrink: 0 }}>{action}</div>}
    </div>
  );
}

// ── Progress Bar ──────────────────────────────────────────────
export function ProgressBar({ value, max = 100, color }: { value: number; max?: number; color?: string }) {
  const pct = Math.min(100, Math.round((value / max) * 100));
  return (
    <div className="ff-progress-bar">
      <div
        className="ff-progress-fill"
        style={{
          width: `${pct}%`,
          background: color ? `linear-gradient(90deg, ${color}, oklch(0.72 0.18 50))` : undefined,
        }}
      />
    </div>
  );
}

// ── Score Ring ────────────────────────────────────────────────
export function ScoreRing({ score, size = 48 }: { score: number; size?: number }) {
  const color = score >= 90 ? 'oklch(0.65 0.18 155)' : score >= 70 ? 'oklch(0.78 0.18 80)' : 'oklch(0.62 0.22 25)';
  const r = (size / 2) - 4;
  const circ = 2 * Math.PI * r;
  const dash = (score / 100) * circ;

  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="oklch(0.20 0.012 240)" strokeWidth={3} />
        <circle
          cx={size / 2} cy={size / 2} r={r} fill="none"
          stroke={color} strokeWidth={3}
          strokeDasharray={`${dash} ${circ - dash}`}
          strokeLinecap="round"
        />
      </svg>
      <div style={{
        position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: "'JetBrains Mono', monospace", fontSize: size < 48 ? 10 : 12, fontWeight: 700, color,
      }}>
        {score}
      </div>
    </div>
  );
}

// ── Empty State ───────────────────────────────────────────────
export function EmptyState({ icon, title, desc }: { icon: ReactNode; title: string; desc: string }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: '60px 24px', textAlign: 'center',
    }}>
      <div style={{
        width: 56, height: 56, borderRadius: 14,
        background: 'oklch(0.15 0.012 240)',
        border: '1px solid oklch(0.20 0.012 240)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: 'oklch(0.40 0.010 240)', marginBottom: 16,
      }}>
        {icon}
      </div>
      <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 15, marginBottom: 6 }}>{title}</div>
      <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 13 }}>{desc}</div>
    </div>
  );
}

// ── Tab Bar ───────────────────────────────────────────────────
export function TabBar({ tabs, active, onChange }: { tabs: { id: string; label: string }[]; active: string; onChange: (id: string) => void }) {
  return (
    <div style={{
      display: 'flex', gap: 4,
      background: 'oklch(0.12 0.01 240)',
      border: '1px solid oklch(0.20 0.012 240)',
      borderRadius: 10, padding: 4,
      width: 'fit-content', flexWrap: 'wrap',
    }}>
      {tabs.map(tab => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          style={{
            background: active === tab.id ? 'oklch(0.18 0.012 240)' : 'transparent',
            border: active === tab.id ? '1px solid oklch(0.26 0.015 240)' : '1px solid transparent',
            color: active === tab.id ? 'oklch(0.94 0.005 240)' : 'oklch(0.60 0.015 240)',
            borderRadius: 7, padding: '6px 14px', cursor: 'pointer',
            fontSize: 12, fontWeight: active === tab.id ? 600 : 400,
            transition: 'all 0.12s', textTransform: 'capitalize',
            fontFamily: "'DM Sans', sans-serif",
          }}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}

// ── Action Button ─────────────────────────────────────────────
export function ActionButton({
  onClick, children, variant = "primary", size = "md", icon, disabled
}: {
  onClick: () => void;
  children: ReactNode;
  variant?: "primary" | "ghost" | "danger";
  size?: "sm" | "md";
  icon?: ReactNode;
  disabled?: boolean;
}) {
  const styles = {
    primary: {
      background: 'oklch(0.72 0.18 50)',
      color: 'oklch(0.09 0.008 240)',
      border: 'none',
    },
    ghost: {
      background: 'transparent',
      color: 'oklch(0.60 0.015 240)',
      border: '1px solid oklch(0.20 0.012 240)',
    },
    danger: {
      background: 'oklch(0.62 0.22 25 / 0.15)',
      color: 'oklch(0.62 0.22 25)',
      border: '1px solid oklch(0.62 0.22 25 / 0.3)',
    },
  }[variant];

  const padding = size === "sm" ? '5px 12px' : '8px 16px';
  const fontSize = size === "sm" ? 12 : 13;

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        ...styles,
        borderRadius: 7, padding, fontSize, fontWeight: 600,
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        display: 'flex', alignItems: 'center', gap: 6,
        transition: 'all 0.12s',
        fontFamily: "'DM Sans', sans-serif",
      }}
    >
      {icon} {children}
    </button>
  );
}
