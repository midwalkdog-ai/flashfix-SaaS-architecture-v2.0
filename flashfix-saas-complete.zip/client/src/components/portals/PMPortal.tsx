/**
 * FlashFix Property Manager Portal
 * Design: Industrial Command Center — dark, orange accent
 */
import { useState } from "react";
import { useApp, SERVICES } from "@/contexts/AppContext";
import {
  StatCard, SectionHeader, StatusBadge, ProgressBar,
  ActionButton, ScoreRing
} from "@/components/shared/UIComponents";
import {
  Building, DollarSign, AlertTriangle, Activity,
  CheckCircle, MapPin, Clock, Plus, Edit3, Zap, BarChart3
} from "lucide-react";
import { toast } from "sonner";

export default function PMPortal() {
  const { currentView } = useApp();

  return (
    <div style={{ padding: '24px', maxWidth: 1200, margin: '0 auto', color: 'oklch(0.94 0.005 240)' }}>
      {currentView === "dashboard" && <PMDashboard />}
      {currentView === "properties" && <PMProperties />}
      {currentView === "jobs" && <PMJobs />}
      {currentView === "quote_builder" && <PMQuoteBuilder />}
      {currentView === "reports" && <PMReports />}
    </div>
  );
}

function PMDashboard() {
  const { jobs, properties } = useApp();
  const myProperties = properties.filter(p => p.pm_id === "usr_02");
  const myJobs = jobs.filter(j => myProperties.some(p => p.id === j.property_id));

  return (
    <div className="animate-fade-up">
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
          <Building size={14} color="oklch(0.65 0.18 250)" />
          <span style={{ color: 'oklch(0.65 0.18 250)', fontSize: 10, fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            PM Portal
          </span>
        </div>
        <h1 style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 26, letterSpacing: '-0.03em' }}>
          Property Manager
        </h1>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 16, marginBottom: 32 }}>
        <StatCard icon={<Building size={16} />} label="My Properties" value={myProperties.length} color="oklch(0.65 0.18 250)" />
        <StatCard icon={<AlertTriangle size={16} />} label="Needs Turnover" value={myProperties.filter(p => p.status === "NEEDS_TURNOVER").length} color="oklch(0.62 0.22 25)" />
        <StatCard icon={<Activity size={16} />} label="Active Jobs" value={myJobs.filter(j => j.status === "IN_PROGRESS").length} color="oklch(0.78 0.18 80)" />
        <StatCard icon={<DollarSign size={16} />} label="Open Value" value={`$${myJobs.filter(j => j.status !== "COMPLETED").reduce((s, j) => s + j.total, 0).toLocaleString()}`} color="oklch(0.72 0.18 50)" />
      </div>

      <SectionHeader title="My Properties" subtitle="Real-time portfolio status" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 14, marginBottom: 32 }}>
        {myProperties.map(p => {
          const activeJob = jobs.find(j => j.property_id === p.id && j.status === "IN_PROGRESS");
          return (
            <div key={p.id} className="ff-card" style={{ padding: '16px', cursor: 'default' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.name}</div>
                  <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 11, display: 'flex', alignItems: 'center', gap: 4 }}>
                    <MapPin size={10} /> {p.address.split(',')[0]}
                  </div>
                </div>
                <ScoreRing score={p.score} size={40} />
              </div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <StatusBadge status={p.status} />
                {activeJob && (
                  <span style={{ fontSize: 11, color: 'oklch(0.78 0.18 80)', fontFamily: "'JetBrains Mono', monospace" }}>
                    {Math.round((activeJob.tasks.filter(t => t.done).length / activeJob.tasks.length) * 100)}% done
                  </span>
                )}
              </div>
              {activeJob && (
                <div style={{ marginTop: 8 }}>
                  <ProgressBar value={Math.round((activeJob.tasks.filter(t => t.done).length / activeJob.tasks.length) * 100)} />
                </div>
              )}
            </div>
          );
        })}
      </div>

      <SectionHeader title="Active Work Orders" subtitle="Jobs in progress and scheduled" />
      <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden' }}>
        {myJobs.map((job, i, arr) => {
          const prop = myProperties.find(p => p.id === job.property_id);
          const progress = Math.round((job.tasks.filter(t => t.done).length / job.tasks.length) * 100);
          return (
            <div key={job.id} style={{ padding: '16px 20px', borderBottom: i < arr.length - 1 ? '1px solid oklch(0.20 0.012 240)' : 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: job.status === "IN_PROGRESS" ? 10 : 0 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 2 }}>{job.title}</div>
                  <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><MapPin size={10} /> {prop?.name}</span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Clock size={10} /> {job.scheduled}</span>
                  </div>
                </div>
                <StatusBadge status={job.status} />
                <span style={{ color: 'oklch(0.65 0.18 155)', fontFamily: "'JetBrains Mono', monospace", fontSize: 14, fontWeight: 700 }}>
                  ${job.total.toLocaleString()}
                </span>
              </div>
              {job.status === "IN_PROGRESS" && (
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontSize: 11, color: 'oklch(0.60 0.015 240)' }}>{job.tasks.filter(t => t.done).length}/{job.tasks.length} tasks</span>
                    <span style={{ fontSize: 11, fontFamily: "'JetBrains Mono', monospace", color: 'oklch(0.60 0.015 240)' }}>{progress}%</span>
                  </div>
                  <ProgressBar value={progress} />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PMProperties() {
  const { properties } = useApp();
  const myProperties = properties.filter(p => p.pm_id === "usr_02");

  return (
    <div className="animate-fade-up">
      <SectionHeader
        title="My Properties"
        subtitle="Full portfolio management"
        tag="PM Portal"
        action={<ActionButton onClick={() => toast.info("Add property coming soon")} icon={<Plus size={13} />}>Add Property</ActionButton>}
      />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
        {myProperties.map(p => (
          <div key={p.id} className="ff-card" style={{ padding: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 14, marginBottom: 4 }}>{p.name}</div>
                <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 12, display: 'flex', alignItems: 'center', gap: 4 }}>
                  <MapPin size={11} /> {p.address}
                </div>
              </div>
              <ScoreRing score={p.score} size={44} />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <StatusBadge status={p.status} />
              <ActionButton onClick={() => toast.info(`Editing ${p.name}`)} variant="ghost" size="sm" icon={<Edit3 size={11} />}>Edit</ActionButton>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function PMJobs() {
  const { jobs, properties } = useApp();
  const myProperties = properties.filter(p => p.pm_id === "usr_02");
  const myJobs = jobs.filter(j => myProperties.some(p => p.id === j.property_id));

  return (
    <div className="animate-fade-up">
      <SectionHeader title="My Jobs" subtitle="Work orders for your properties" tag="PM Portal" />
      <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden' }}>
        {myJobs.map((job, i, arr) => {
          const prop = myProperties.find(p => p.id === job.property_id);
          const progress = Math.round((job.tasks.filter(t => t.done).length / job.tasks.length) * 100);
          return (
            <div key={job.id} style={{ padding: '16px 20px', borderBottom: i < arr.length - 1 ? '1px solid oklch(0.20 0.012 240)' : 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: job.status === "IN_PROGRESS" ? 10 : 0 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 2 }}>{job.title}</div>
                  <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><MapPin size={10} /> {prop?.name}</span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Clock size={10} /> {job.scheduled}</span>
                  </div>
                </div>
                <StatusBadge status={job.priority} />
                <StatusBadge status={job.status} />
                <span style={{ color: 'oklch(0.65 0.18 155)', fontFamily: "'JetBrains Mono', monospace", fontSize: 14, fontWeight: 700 }}>
                  ${job.total.toLocaleString()}
                </span>
              </div>
              {job.status === "IN_PROGRESS" && (
                <div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontSize: 11, color: 'oklch(0.60 0.015 240)' }}>{job.tasks.filter(t => t.done).length}/{job.tasks.length} tasks</span>
                    <span style={{ fontSize: 11, fontFamily: "'JetBrains Mono', monospace", color: 'oklch(0.60 0.015 240)' }}>{progress}%</span>
                  </div>
                  <ProgressBar value={progress} />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PMQuoteBuilder() {
  const { properties } = useApp();
  const myProperties = properties.filter(p => p.pm_id === "usr_02");
  const [selectedProperty, setSelectedProperty] = useState("");
  const [lineItems, setLineItems] = useState<{ service: typeof SERVICES[0]; qty: number }[]>([]);
  const [catFilter, setCatFilter] = useState("All");
  const categories = Array.from(new Set(SERVICES.map(s => s.category)));
  const filteredServices = catFilter === "All" ? SERVICES : SERVICES.filter(s => s.category === catFilter);
  const total = lineItems.reduce((sum, item) => sum + item.service.price * item.qty, 0);

  const addItem = (service: typeof SERVICES[0]) => {
    const existing = lineItems.find(i => i.service.name === service.name);
    if (existing) {
      setLineItems(prev => prev.map(i => i.service.name === service.name ? { ...i, qty: i.qty + 1 } : i));
    } else {
      setLineItems(prev => [...prev, { service, qty: 1 }]);
    }
    toast.success(`Added: ${service.name}`);
  };

  return (
    <div className="animate-fade-up">
      <SectionHeader title="Quote Builder" subtitle="Build quotes from the pricing catalog" tag="PM Portal" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 20 }}>
        <div>
          <select value={selectedProperty} onChange={e => setSelectedProperty(e.target.value)} className="ff-input" style={{ marginBottom: 12 }}>
            <option value="">Select Property...</option>
            {myProperties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 12 }}>
            {["All", ...categories].map(c => (
              <button key={c} onClick={() => setCatFilter(c)} style={{
                background: catFilter === c ? 'oklch(0.65 0.18 250 / 0.15)' : 'transparent',
                border: catFilter === c ? '1px solid oklch(0.65 0.18 250 / 0.4)' : '1px solid oklch(0.20 0.012 240)',
                color: catFilter === c ? 'oklch(0.65 0.18 250)' : 'oklch(0.60 0.015 240)',
                borderRadius: 5, padding: '4px 10px', cursor: 'pointer', fontSize: 11,
              }}>
                {c}
              </button>
            ))}
          </div>
          <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden', maxHeight: 460, overflowY: 'auto' }}>
            {filteredServices.map(s => (
              <div key={s.name} className="ff-table-row" style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{s.name}</div>
                  <div style={{ fontSize: 11, color: 'oklch(0.60 0.015 240)' }}>{s.unit}</div>
                </div>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 700, color: 'oklch(0.65 0.18 155)' }}>${s.price}</span>
                <button onClick={() => addItem(s)} style={{
                  background: 'oklch(0.65 0.18 250 / 0.15)', border: '1px solid oklch(0.65 0.18 250 / 0.3)',
                  color: 'oklch(0.65 0.18 250)', borderRadius: 6, padding: '4px 10px', cursor: 'pointer', fontSize: 12,
                  display: 'flex', alignItems: 'center', gap: 4,
                }}>
                  <Plus size={12} /> Add
                </button>
              </div>
            ))}
          </div>
        </div>

        <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, padding: '20px', height: 'fit-content', position: 'sticky', top: 20 }}>
          <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 16, marginBottom: 16 }}>Quote Summary</div>
          {lineItems.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px 0', color: 'oklch(0.40 0.010 240)', fontSize: 13 }}>Add services from the catalog</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
              {lineItems.map(item => (
                <div key={item.service.name} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ flex: 1, fontSize: 12 }}>{item.service.name}</div>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: 'oklch(0.65 0.18 155)' }}>
                    x{item.qty} = ${(item.service.price * item.qty).toFixed(2)}
                  </span>
                  <button onClick={() => setLineItems(prev => prev.filter(i => i.service.name !== item.service.name))} style={{ background: 'none', border: 'none', color: 'oklch(0.62 0.22 25)', cursor: 'pointer', fontSize: 14 }}>×</button>
                </div>
              ))}
            </div>
          )}
          <div style={{ borderTop: '1px solid oklch(0.20 0.012 240)', paddingTop: 16, marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 15 }}>Total</span>
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 22, fontWeight: 700, color: 'oklch(0.65 0.18 250)' }}>${total.toFixed(2)}</span>
          </div>
          <button onClick={() => {
            if (!selectedProperty) { toast.error("Select a property first"); return; }
            if (lineItems.length === 0) { toast.error("Add at least one service"); return; }
            toast.success(`Quote for $${total.toFixed(2)} submitted!`);
            setLineItems([]);
          }} style={{
            width: '100%', padding: '12px', borderRadius: 8,
            background: 'oklch(0.65 0.18 250)', color: 'oklch(0.09 0.008 240)',
            border: 'none', fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 14, cursor: 'pointer',
          }}>
            Submit for Approval
          </button>
        </div>
      </div>
    </div>
  );
}

function PMReports() {
  const { jobs, properties } = useApp();
  const myProperties = properties.filter(p => p.pm_id === "usr_02");
  const myJobs = jobs.filter(j => myProperties.some(p => p.id === j.property_id));
  const totalSpend = myJobs.reduce((s, j) => s + j.total, 0);

  return (
    <div className="animate-fade-up">
      <SectionHeader title="Portfolio Reports" subtitle="Performance metrics for your properties" tag="PM Portal" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 16, marginBottom: 32 }}>
        <StatCard icon={<DollarSign size={16} />} label="Total Spend" value={`$${totalSpend.toLocaleString()}`} color="oklch(0.65 0.18 250)" />
        <StatCard icon={<CheckCircle size={16} />} label="Jobs Completed" value={myJobs.filter(j => j.status === "COMPLETED").length} color="oklch(0.65 0.18 155)" />
        <StatCard icon={<Building size={16} />} label="Rent Ready" value={myProperties.filter(p => p.status === "RENT_READY").length} color="oklch(0.65 0.18 155)" />
        <StatCard icon={<AlertTriangle size={16} />} label="Needs Turnover" value={myProperties.filter(p => p.status === "NEEDS_TURNOVER").length} color="oklch(0.62 0.22 25)" />
      </div>

      <SectionHeader title="Property Scores" subtitle="Readiness score per property" />
      <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden' }}>
        {myProperties.map((p, i, arr) => (
          <div key={p.id} style={{ padding: '14px 20px', borderBottom: i < arr.length - 1 ? '1px solid oklch(0.20 0.012 240)' : 'none', display: 'flex', alignItems: 'center', gap: 16 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 2 }}>{p.name}</div>
              <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 11 }}>{p.address}</div>
            </div>
            <StatusBadge status={p.status} />
            <ScoreRing score={p.score} size={44} />
          </div>
        ))}
      </div>
    </div>
  );
}
