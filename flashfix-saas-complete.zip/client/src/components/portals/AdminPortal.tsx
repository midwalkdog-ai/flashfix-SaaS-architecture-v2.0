/**
 * FlashFix Admin Portal — Platform-wide oversight
 * Design: Industrial Command Center — dark, orange accent
 */
import { useState } from "react";
import { useApp, SERVICES, MOCK_PROPERTIES } from "@/contexts/AppContext";
import {
  StatCard, SectionHeader, StatusBadge, ProgressBar,
  ActionButton, ScoreRing
} from "@/components/shared/UIComponents";
import {
  Building, DollarSign, Users, Shield, BarChart3,
  Activity, AlertTriangle, CheckCircle, MapPin, Clock, Plus, Edit3, Zap
} from "lucide-react";
import { toast } from "sonner";

export default function AdminPortal() {
  const { currentView } = useApp();

  return (
    <div style={{ padding: '24px', maxWidth: 1200, margin: '0 auto', color: 'oklch(0.94 0.005 240)' }}>
      {currentView === "dashboard" && <AdminDashboard />}
      {currentView === "properties" && <AdminProperties />}
      {currentView === "jobs" && <AdminJobs />}
      {currentView === "pricing" && <PricingCatalog />}
      {currentView === "users" && <UserManagement />}
      {currentView === "audit_log" && <AuditLog />}
      {currentView === "quote_builder" && <QuoteBuilderView />}
      {currentView === "reports" && <AdminReports />}
    </div>
  );
}

function AdminDashboard() {
  const { jobs, properties, auditLogs } = useApp();
  const activeJobs = jobs.filter(j => j.status === "IN_PROGRESS").length;
  const needsTurnover = properties.filter(p => p.status === "NEEDS_TURNOVER").length;
  const completedJobs = jobs.filter(j => j.status === "COMPLETED").length;
  const totalRevenue = jobs.reduce((s, j) => s + j.total, 0);

  return (
    <div className="animate-fade-up">
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
          <Zap size={14} color="oklch(0.72 0.18 50)" />
          <span style={{ color: 'oklch(0.72 0.18 50)', fontSize: 10, fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Admin Portal
          </span>
        </div>
        <h1 style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 26, letterSpacing: '-0.03em' }}>
          Platform Overview
        </h1>
        <p style={{ color: 'oklch(0.60 0.015 240)', fontSize: 13, marginTop: 4 }}>
          Real-time visibility across all properties, jobs, and contractors.
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 16, marginBottom: 32 }}>
        <StatCard icon={<Building size={16} />} label="Total Properties" value={properties.length} color="oklch(0.65 0.18 250)" />
        <StatCard icon={<AlertTriangle size={16} />} label="Needs Turnover" value={needsTurnover} color="oklch(0.62 0.22 25)" />
        <StatCard icon={<Activity size={16} />} label="Active Jobs" value={activeJobs} color="oklch(0.78 0.18 80)" />
        <StatCard icon={<CheckCircle size={16} />} label="Completed" value={completedJobs} color="oklch(0.65 0.18 155)" trend="+2 this week" />
        <StatCard icon={<DollarSign size={16} />} label="Total Revenue" value={`$${totalRevenue.toLocaleString()}`} color="oklch(0.72 0.18 50)" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 24 }}>
        {/* Active Jobs */}
        <div>
          <SectionHeader title="Active Jobs" subtitle="Currently in progress" />
          <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden' }}>
            {jobs.filter(j => j.status !== "COMPLETED").map((job, i, arr) => {
              const prop = MOCK_PROPERTIES.find(p => p.id === job.property_id);
              const progress = Math.round((job.tasks.filter(t => t.done).length / job.tasks.length) * 100);
              return (
                <div key={job.id} style={{ padding: '14px 16px', borderBottom: i < arr.length - 1 ? '1px solid oklch(0.20 0.012 240)' : 'none' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: job.status === "IN_PROGRESS" ? 8 : 0 }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 2 }}>{job.title}</div>
                      <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 11, display: 'flex', alignItems: 'center', gap: 4 }}>
                        <MapPin size={10} /> {prop?.name}
                      </div>
                    </div>
                    <StatusBadge status={job.status} />
                    <span style={{ color: 'oklch(0.65 0.18 155)', fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 700 }}>
                      ${job.total.toLocaleString()}
                    </span>
                  </div>
                  {job.status === "IN_PROGRESS" && (
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                        <span style={{ fontSize: 11, color: 'oklch(0.60 0.015 240)' }}>{job.tasks.filter(t => t.done).length}/{job.tasks.length} tasks</span>
                        <span style={{ fontSize: 11, color: 'oklch(0.60 0.015 240)', fontFamily: "'JetBrains Mono', monospace" }}>{progress}%</span>
                      </div>
                      <ProgressBar value={progress} />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Audit Trail */}
        <div>
          <SectionHeader title="Recent Activity" subtitle="Platform-wide audit trail" />
          <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden' }}>
            {auditLogs.slice(0, 5).map((log, i, arr) => {
              const roleColor: Record<string, string> = {
                ADMIN: 'oklch(0.72 0.18 50)',
                PROPERTY_MANAGER: 'oklch(0.65 0.18 250)',
                CONTRACTOR: 'oklch(0.65 0.18 155)',
              };
              const c = roleColor[log.role] || 'oklch(0.60 0.015 240)';
              return (
                <div key={log.id} style={{ padding: '12px 16px', borderBottom: i < arr.length - 1 ? '1px solid oklch(0.20 0.012 240)' : 'none' }}>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                    <div style={{
                      width: 28, height: 28, borderRadius: '50%',
                      background: `${c.replace(')', ' / 0.15)')}`,
                      border: `1px solid ${c.replace(')', ' / 0.3)')}`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 9, fontWeight: 700, color: c,
                      fontFamily: "'JetBrains Mono', monospace", flexShrink: 0,
                    }}>
                      {log.actor.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 2 }}>{log.actor}</div>
                      <div style={{ fontSize: 11, color: 'oklch(0.60 0.015 240)', lineHeight: 1.4 }}>{log.detail}</div>
                      <div style={{ fontSize: 10, color: 'oklch(0.40 0.010 240)', marginTop: 4, fontFamily: "'JetBrains Mono', monospace" }}>
                        {new Date(log.ts).toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Property Grid */}
      <SectionHeader title="Property Portfolio" subtitle="Status across all managed properties" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 14 }}>
        {properties.map(p => (
          <div key={p.id} className="ff-card" style={{ padding: '16px', cursor: 'default' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 10 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{p.name}</div>
                <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 11, display: 'flex', alignItems: 'center', gap: 4 }}>
                  <MapPin size={10} /> {p.address.split(',')[0]}
                </div>
              </div>
              <ScoreRing score={p.score} size={40} />
            </div>
            <StatusBadge status={p.status} />
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminProperties() {
  const { properties } = useApp();
  return (
    <div className="animate-fade-up">
      <SectionHeader
        title="All Properties"
        subtitle="Platform-wide property management"
        tag="Admin"
        action={<ActionButton onClick={() => toast.info("Add property coming soon")} icon={<Plus size={13} />}>Add Property</ActionButton>}
      />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
        {properties.map(p => (
          <div key={p.id} className="ff-card" style={{ padding: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 14, marginBottom: 4 }}>{p.name}</div>
                <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 12, display: 'flex', alignItems: 'center', gap: 4 }}>
                  <MapPin size={11} /> {p.address}
                </div>
              </div>
              <ScoreRing score={p.score} size={44} />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <StatusBadge status={p.status} />
              <ActionButton onClick={() => toast.info(`Editing ${p.name}`)} variant="ghost" size="sm" icon={<Edit3 size={11} />}>Edit</ActionButton>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminJobs() {
  const { jobs, properties } = useApp();
  const [filter, setFilter] = useState("ALL");
  const filters = ["ALL", "SCHEDULED", "IN_PROGRESS", "COMPLETED"];
  const filtered = filter === "ALL" ? jobs : jobs.filter(j => j.status === filter);

  return (
    <div className="animate-fade-up">
      <SectionHeader title="All Jobs" subtitle="Platform-wide job management" tag="Admin" />
      <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        {filters.map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{
            background: filter === f ? 'oklch(0.72 0.18 50 / 0.15)' : 'transparent',
            border: filter === f ? '1px solid oklch(0.72 0.18 50 / 0.4)' : '1px solid oklch(0.20 0.012 240)',
            color: filter === f ? 'oklch(0.72 0.18 50)' : 'oklch(0.60 0.015 240)',
            borderRadius: 6, padding: '5px 12px', cursor: 'pointer', fontSize: 12, fontWeight: 500,
          }}>
            {f.replace('_', ' ')}
          </button>
        ))}
      </div>
      <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden' }}>
        {filtered.map((job, i, arr) => {
          const prop = properties.find(p => p.id === job.property_id);
          const progress = Math.round((job.tasks.filter(t => t.done).length / job.tasks.length) * 100);
          return (
            <div key={job.id} className="ff-table-row" style={{ padding: '16px 20px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 2 }}>{job.title}</div>
                  <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><MapPin size={10} /> {prop?.name}</span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Clock size={10} /> {job.scheduled}</span>
                  </div>
                </div>
                <StatusBadge status={job.priority} />
                <StatusBadge status={job.status} />
                <span style={{ color: 'oklch(0.65 0.18 155)', fontFamily: "'JetBrains Mono', monospace", fontSize: 14, fontWeight: 700, minWidth: 70, textAlign: 'right' }}>
                  ${job.total.toLocaleString()}
                </span>
              </div>
              {job.status === "IN_PROGRESS" && (
                <div style={{ marginTop: 10 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                    <span style={{ fontSize: 11, color: 'oklch(0.60 0.015 240)' }}>{job.tasks.filter(t => t.done).length}/{job.tasks.length} tasks</span>
                    <span style={{ fontSize: 11, fontFamily: "'JetBrains Mono', monospace", color: 'oklch(0.60 0.015 240)' }}>{progress}%</span>
                  </div>
                  <ProgressBar value={progress} />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PricingCatalog() {
  const categories = Array.from(new Set(SERVICES.map(s => s.category)));
  const [selected, setSelected] = useState("All");
  const filtered = selected === "All" ? SERVICES : SERVICES.filter(s => s.category === selected);

  return (
    <div className="animate-fade-up">
      <SectionHeader
        title="Pricing Catalog"
        subtitle="Manage service rates and categories"
        tag="Admin"
        action={<ActionButton onClick={() => toast.success("New service added")} icon={<Plus size={13} />}>Add Service</ActionButton>}
      />
      <div style={{ display: 'flex', gap: 6, marginBottom: 20, flexWrap: 'wrap' }}>
        {["All", ...categories].map(c => (
          <button key={c} onClick={() => setSelected(c)} style={{
            background: selected === c ? 'oklch(0.72 0.18 50 / 0.15)' : 'transparent',
            border: selected === c ? '1px solid oklch(0.72 0.18 50 / 0.4)' : '1px solid oklch(0.20 0.012 240)',
            color: selected === c ? 'oklch(0.72 0.18 50)' : 'oklch(0.60 0.015 240)',
            borderRadius: 6, padding: '5px 12px', cursor: 'pointer', fontSize: 11, fontWeight: 500,
          }}>
            {c}
          </button>
        ))}
      </div>
      <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden' }}>
        {/* Header */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto auto auto', padding: '10px 20px', borderBottom: '1px solid oklch(0.20 0.012 240)' }}>
          {["Service", "Unit", "Price", ""].map(h => (
            <div key={h} style={{ fontSize: 10, fontFamily: "'JetBrains Mono', monospace", color: 'oklch(0.40 0.010 240)', textTransform: 'uppercase', letterSpacing: '0.06em', textAlign: h === "Price" ? 'right' : 'left', padding: h === "Price" || h === "Unit" ? '0 16px' : '0' }}>
              {h}
            </div>
          ))}
        </div>
        {filtered.map(s => (
          <div key={s.name} className="ff-table-row" style={{ display: 'grid', gridTemplateColumns: '1fr auto auto auto' }}>
            <div style={{ padding: '12px 20px' }}>
              <div style={{ fontSize: 13, fontWeight: 500 }}>{s.name}</div>
              <div style={{ fontSize: 11, color: 'oklch(0.60 0.015 240)', marginTop: 2 }}>{s.category}</div>
            </div>
            <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', fontSize: 12, color: 'oklch(0.60 0.015 240)', fontFamily: "'JetBrains Mono', monospace" }}>
              {s.unit}
            </div>
            <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'flex-end', fontSize: 14, fontWeight: 700, color: 'oklch(0.65 0.18 155)', fontFamily: "'JetBrains Mono', monospace" }}>
              ${s.price}
            </div>
            <div style={{ padding: '12px 16px', display: 'flex', alignItems: 'center' }}>
              <ActionButton onClick={() => toast.info(`Editing: ${s.name}`)} variant="ghost" size="sm" icon={<Edit3 size={11} />}>Edit</ActionButton>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function UserManagement() {
  const users = [
    { id: "usr_01", email: "admin@flashfix.io", role: "ADMIN", name: "Jordan Blake", avatar: "JB", active: true },
    { id: "usr_02", email: "sarah@propertyco.com", role: "PROPERTY_MANAGER", name: "Sarah Chen", avatar: "SC", active: true },
    { id: "usr_03", email: "mike@flashfix.io", role: "CONTRACTOR", name: "Mike Torres", avatar: "MT", active: true },
    { id: "usr_04", email: "alex@propertyco.com", role: "PROPERTY_MANAGER", name: "Alex Rivera", avatar: "AR", active: false },
  ];
  const roleColor: Record<string, string> = {
    ADMIN: 'oklch(0.72 0.18 50)',
    PROPERTY_MANAGER: 'oklch(0.65 0.18 250)',
    CONTRACTOR: 'oklch(0.65 0.18 155)',
  };

  return (
    <div className="animate-fade-up">
      <SectionHeader
        title="User Management"
        subtitle="Manage roles, permissions, and invitations"
        tag="Admin"
        action={<ActionButton onClick={() => toast.success("Invite link copied!")} icon={<Plus size={13} />}>Invite User</ActionButton>}
      />
      <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden' }}>
        {users.map(u => {
          const c = roleColor[u.role] || 'oklch(0.60 0.015 240)';
          return (
            <div key={u.id} className="ff-table-row" style={{ padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 16 }}>
              <div style={{
                width: 38, height: 38, borderRadius: '50%',
                background: `${c.replace(')', ' / 0.2)')}`,
                border: `2px solid ${c.replace(')', ' / 0.4)')}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 12, fontWeight: 700, color: c,
                fontFamily: "'JetBrains Mono', monospace",
              }}>
                {u.avatar}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 2 }}>{u.name}</div>
                <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 12, fontFamily: "'JetBrains Mono', monospace" }}>{u.email}</div>
              </div>
              <span style={{
                background: `${c.replace(')', ' / 0.12)')}`, color: c,
                border: `1px solid ${c.replace(')', ' / 0.25)')}`,
                fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 4,
                fontFamily: "'JetBrains Mono', monospace", textTransform: 'uppercase', letterSpacing: '0.06em',
              }}>
                {u.role.replace("_", " ")}
              </span>
              <span style={{ fontSize: 10, fontFamily: "'JetBrains Mono', monospace", color: u.active ? 'oklch(0.65 0.18 155)' : 'oklch(0.60 0.015 240)' }}>
                {u.active ? "● ACTIVE" : "○ INACTIVE"}
              </span>
              <ActionButton onClick={() => toast.info(`Managing ${u.name}`)} variant="ghost" size="sm">Manage</ActionButton>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function AuditLog() {
  const { auditLogs } = useApp();
  const roleColor: Record<string, string> = {
    ADMIN: 'oklch(0.72 0.18 50)',
    PROPERTY_MANAGER: 'oklch(0.65 0.18 250)',
    CONTRACTOR: 'oklch(0.65 0.18 155)',
  };

  return (
    <div className="animate-fade-up">
      <SectionHeader title="Audit Log" subtitle="Immutable record of all platform actions" tag="Admin" />
      <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden', marginBottom: 12 }}>
        {auditLogs.map((log, i, arr) => {
          const c = roleColor[log.role] || 'oklch(0.60 0.015 240)';
          return (
            <div key={log.id} className="ff-table-row" style={{ padding: '12px 20px', display: 'flex', gap: 16, alignItems: 'flex-start', borderBottom: i < arr.length - 1 ? '1px solid oklch(0.20 0.012 240)' : 'none' }}>
              <div style={{ fontSize: 11, fontFamily: "'JetBrains Mono', monospace", color: 'oklch(0.60 0.015 240)', minWidth: 140 }}>
                {new Date(log.ts).toLocaleString()}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, minWidth: 120 }}>
                <div style={{
                  width: 24, height: 24, borderRadius: '50%',
                  background: `${c.replace(')', ' / 0.15)')}`,
                  border: `1px solid ${c.replace(')', ' / 0.3)')}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 8, fontWeight: 700, color: c,
                  fontFamily: "'JetBrains Mono', monospace",
                }}>
                  {log.actor.split(' ').map(n => n[0]).join('')}
                </div>
                <span style={{ fontSize: 12, fontWeight: 500 }}>{log.actor}</span>
              </div>
              <div style={{ minWidth: 140 }}>
                <span style={{
                  background: `${c.replace(')', ' / 0.12)')}`, color: c,
                  border: `1px solid ${c.replace(')', ' / 0.25)')}`,
                  fontSize: 10, fontWeight: 700, padding: '2px 7px', borderRadius: 3,
                  fontFamily: "'JetBrains Mono', monospace",
                }}>
                  {log.action.replace(/_/g, ' ')}
                </span>
              </div>
              <div style={{ flex: 1, fontSize: 12, color: 'oklch(0.75 0.010 240)', lineHeight: 1.4 }}>
                {log.detail}
              </div>
            </div>
          );
        })}
      </div>
      <p style={{ fontSize: 11, color: 'oklch(0.40 0.010 240)', fontFamily: "'JetBrains Mono', monospace" }}>
        ⚠ Audit logs are immutable — no UPDATE or DELETE operations are permitted.
      </p>
    </div>
  );
}

function QuoteBuilderView() {
  const { properties } = useApp();
  const [selectedProperty, setSelectedProperty] = useState("");
  const [lineItems, setLineItems] = useState<{ service: typeof SERVICES[0]; qty: number }[]>([]);
  const categories = Array.from(new Set(SERVICES.map(s => s.category)));
  const [catFilter, setCatFilter] = useState("All");

  const filteredServices = catFilter === "All" ? SERVICES : SERVICES.filter(s => s.category === catFilter);
  const total = lineItems.reduce((sum, item) => sum + item.service.price * item.qty, 0);

  const addItem = (service: typeof SERVICES[0]) => {
    const existing = lineItems.find(i => i.service.name === service.name);
    if (existing) {
      setLineItems(prev => prev.map(i => i.service.name === service.name ? { ...i, qty: i.qty + 1 } : i));
    } else {
      setLineItems(prev => [...prev, { service, qty: 1 }]);
    }
    toast.success(`Added: ${service.name}`);
  };

  return (
    <div className="animate-fade-up">
      <SectionHeader title="Quote Builder" subtitle="Build and send quotes from the pricing catalog" tag="Admin" />
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 20 }}>
        <div>
          <select value={selectedProperty} onChange={e => setSelectedProperty(e.target.value)} className="ff-input" style={{ marginBottom: 12 }}>
            <option value="">Select Property...</option>
            {properties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 12 }}>
            {["All", ...categories].map(c => (
              <button key={c} onClick={() => setCatFilter(c)} style={{
                background: catFilter === c ? 'oklch(0.72 0.18 50 / 0.15)' : 'transparent',
                border: catFilter === c ? '1px solid oklch(0.72 0.18 50 / 0.4)' : '1px solid oklch(0.20 0.012 240)',
                color: catFilter === c ? 'oklch(0.72 0.18 50)' : 'oklch(0.60 0.015 240)',
                borderRadius: 5, padding: '4px 10px', cursor: 'pointer', fontSize: 11,
              }}>
                {c}
              </button>
            ))}
          </div>
          <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden', maxHeight: 480, overflowY: 'auto' }}>
            {filteredServices.map(s => (
              <div key={s.name} className="ff-table-row" style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 500 }}>{s.name}</div>
                  <div style={{ fontSize: 11, color: 'oklch(0.60 0.015 240)' }}>{s.category} · {s.unit}</div>
                </div>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 700, color: 'oklch(0.65 0.18 155)', minWidth: 60, textAlign: 'right' }}>
                  ${s.price}
                </span>
                <button onClick={() => addItem(s)} style={{
                  background: 'oklch(0.72 0.18 50 / 0.15)', border: '1px solid oklch(0.72 0.18 50 / 0.3)',
                  color: 'oklch(0.72 0.18 50)', borderRadius: 6, padding: '4px 10px', cursor: 'pointer', fontSize: 12,
                  display: 'flex', alignItems: 'center', gap: 4,
                }}>
                  <Plus size={12} /> Add
                </button>
              </div>
            ))}
          </div>
        </div>

        <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, padding: '20px', position: 'sticky', top: 20, height: 'fit-content' }}>
          <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 16, marginBottom: 16 }}>Quote Summary</div>
          {lineItems.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px 0', color: 'oklch(0.40 0.010 240)', fontSize: 13 }}>Add services from the catalog</div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
              {lineItems.map(item => (
                <div key={item.service.name} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ flex: 1, fontSize: 12 }}>{item.service.name}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <button onClick={() => {
                      if (item.qty <= 1) setLineItems(prev => prev.filter(i => i.service.name !== item.service.name));
                      else setLineItems(prev => prev.map(i => i.service.name === item.service.name ? { ...i, qty: i.qty - 1 } : i));
                    }} style={{ background: 'oklch(0.15 0.012 240)', border: '1px solid oklch(0.20 0.012 240)', color: 'oklch(0.94 0.005 240)', borderRadius: 4, width: 22, height: 22, cursor: 'pointer', fontSize: 14, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>−</button>
                    <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, minWidth: 20, textAlign: 'center' }}>{item.qty}</span>
                    <button onClick={() => setLineItems(prev => prev.map(i => i.service.name === item.service.name ? { ...i, qty: i.qty + 1 } : i))} style={{ background: 'oklch(0.15 0.012 240)', border: '1px solid oklch(0.20 0.012 240)', color: 'oklch(0.94 0.005 240)', borderRadius: 4, width: 22, height: 22, cursor: 'pointer', fontSize: 14, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</button>
                  </div>
                  <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: 'oklch(0.65 0.18 155)', minWidth: 60, textAlign: 'right' }}>
                    ${(item.service.price * item.qty).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
          )}
          <div style={{ borderTop: '1px solid oklch(0.20 0.012 240)', paddingTop: 16, marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 15 }}>Total</span>
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 22, fontWeight: 700, color: 'oklch(0.72 0.18 50)' }}>${total.toFixed(2)}</span>
          </div>
          <button onClick={() => {
            if (!selectedProperty) { toast.error("Please select a property first"); return; }
            if (lineItems.length === 0) { toast.error("Add at least one service"); return; }
            toast.success(`Quote for $${total.toFixed(2)} sent for approval!`);
            setLineItems([]);
          }} style={{
            width: '100%', padding: '12px', borderRadius: 8,
            background: 'oklch(0.72 0.18 50)', color: 'oklch(0.09 0.008 240)',
            border: 'none', fontFamily: "'Space Grotesk', sans-serif",
            fontWeight: 700, fontSize: 14, cursor: 'pointer',
          }}>
            Send Quote for Approval
          </button>
        </div>
      </div>
    </div>
  );
}

function AdminReports() {
  const { jobs, properties } = useApp();
  const totalRevenue = jobs.reduce((s, j) => s + j.total, 0);
  const avgJobValue = jobs.length > 0 ? totalRevenue / jobs.length : 0;
  const completionRate = jobs.length > 0 ? Math.round((jobs.filter(j => j.status === "COMPLETED").length / jobs.length) * 100) : 0;

  return (
    <div className="animate-fade-up">
      <SectionHeader title="Reports & Analytics" subtitle="Platform performance metrics" tag="Admin" />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 16, marginBottom: 32 }}>
        <StatCard icon={<DollarSign size={16} />} label="Total Revenue" value={`$${totalRevenue.toLocaleString()}`} color="oklch(0.72 0.18 50)" />
        <StatCard icon={<BarChart3 size={16} />} label="Avg Job Value" value={`$${avgJobValue.toFixed(0)}`} color="oklch(0.65 0.18 250)" />
        <StatCard icon={<CheckCircle size={16} />} label="Completion Rate" value={`${completionRate}%`} color="oklch(0.65 0.18 155)" />
        <StatCard icon={<Building size={16} />} label="Rent Ready" value={properties.filter(p => p.status === "RENT_READY").length} color="oklch(0.65 0.18 155)" />
      </div>

      <SectionHeader title="Revenue by Job" subtitle="Breakdown of all job values" />
      <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden' }}>
        {[...jobs].sort((a, b) => b.total - a.total).map((job, i, arr) => {
          const prop = properties.find(p => p.id === job.property_id);
          const pct = totalRevenue > 0 ? (job.total / totalRevenue) * 100 : 0;
          return (
            <div key={job.id} className="ff-table-row" style={{ padding: '14px 20px', borderBottom: i < arr.length - 1 ? '1px solid oklch(0.20 0.012 240)' : 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 8 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 13 }}>{job.title}</div>
                  <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 11 }}>{prop?.name}</div>
                </div>
                <StatusBadge status={job.status} />
                <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 14, fontWeight: 700, color: 'oklch(0.65 0.18 155)' }}>
                  ${job.total.toLocaleString()}
                </span>
              </div>
              <ProgressBar value={pct} color="oklch(0.65 0.18 250)" />
            </div>
          );
        })}
      </div>
    </div>
  );
}
