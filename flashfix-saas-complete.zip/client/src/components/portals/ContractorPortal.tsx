/**
 * FlashFix Contractor Portal — Mobile-optimized field app
 * Design: Industrial Command Center — dark, orange accent
 */
import { useState } from "react";
import { useApp, Job, JobTask } from "@/contexts/AppContext";
import {
  StatCard, SectionHeader, StatusBadge, ProgressBar
} from "@/components/shared/UIComponents";
import {
  CheckCircle, Clock, MapPin, Camera,
  Navigation, Phone, ChevronRight, ArrowLeft, Zap, Activity
} from "lucide-react";
import { toast } from "sonner";

export default function ContractorPortal() {
  const { currentView } = useApp();
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);

  if (selectedJobId) {
    return <JobDetailView jobId={selectedJobId} onBack={() => setSelectedJobId(null)} />;
  }

  return (
    <div style={{ padding: '24px', maxWidth: 800, margin: '0 auto', color: 'oklch(0.94 0.005 240)' }}>
      {(currentView === "dashboard" || currentView === "jobs") && (
        <ContractorDashboard onSelectJob={setSelectedJobId} />
      )}
    </div>
  );
}

function ContractorDashboard({ onSelectJob }: { onSelectJob: (id: string) => void }) {
  const { jobs, user } = useApp();
  const myJobs = jobs.filter(j => j.contractor_id === user?.id);
  const activeJobs = myJobs.filter(j => j.status === "IN_PROGRESS");
  const scheduled = myJobs.filter(j => j.status === "SCHEDULED");
  const completed = myJobs.filter(j => j.status === "COMPLETED");

  return (
    <div className="animate-fade-up">
      <div style={{ marginBottom: 28 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
          <Zap size={14} color="oklch(0.65 0.18 155)" />
          <span style={{ color: 'oklch(0.65 0.18 155)', fontSize: 10, fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase' }}>
            Contractor App
          </span>
        </div>
        <h1 style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 26, letterSpacing: '-0.03em' }}>
          My Jobs
        </h1>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 14, marginBottom: 28 }}>
        <StatCard icon={<Activity size={16} />} label="Active" value={activeJobs.length} color="oklch(0.78 0.18 80)" />
        <StatCard icon={<Clock size={16} />} label="Scheduled" value={scheduled.length} color="oklch(0.65 0.18 250)" />
        <StatCard icon={<CheckCircle size={16} />} label="Completed" value={completed.length} color="oklch(0.65 0.18 155)" />
      </div>

      {activeJobs.length > 0 && (
        <div style={{ marginBottom: 24 }}>
          <SectionHeader title="Active Jobs" subtitle="Currently in progress" />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {activeJobs.map(job => <ActiveJobCard key={job.id} job={job} onSelect={() => onSelectJob(job.id)} />)}
          </div>
        </div>
      )}

      {scheduled.length > 0 && (
        <div style={{ marginBottom: 24 }}>
          <SectionHeader title="Upcoming Jobs" subtitle="Scheduled and ready" />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {scheduled.map(job => <JobCard key={job.id} job={job} onSelect={() => onSelectJob(job.id)} />)}
          </div>
        </div>
      )}

      {completed.length > 0 && (
        <div>
          <SectionHeader title="Completed" subtitle="Finished jobs" />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {completed.map(job => <JobCard key={job.id} job={job} onSelect={() => onSelectJob(job.id)} />)}
          </div>
        </div>
      )}
    </div>
  );
}

function ActiveJobCard({ job, onSelect }: { job: Job; onSelect: () => void }) {
  const { properties } = useApp();
  const prop = properties.find(p => p.id === job.property_id);
  const doneTasks = job.tasks.filter(t => t.done).length;
  const progress = Math.round((doneTasks / job.tasks.length) * 100);

  return (
    <div onClick={onSelect} style={{
      background: 'oklch(0.12 0.01 240)',
      border: '1px solid oklch(0.78 0.18 80 / 0.4)',
      borderLeft: '3px solid oklch(0.78 0.18 80)',
      borderRadius: 12, padding: '20px',
      cursor: 'pointer',
      boxShadow: '0 4px 20px oklch(0.78 0.18 80 / 0.1)',
      transition: 'all 0.15s',
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
        <div>
          <div style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 16, marginBottom: 4 }}>{job.title}</div>
          <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
            <MapPin size={12} /> {prop?.address}
          </div>
        </div>
        <StatusBadge status={job.status} />
      </div>

      <div style={{ marginBottom: 12 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
          <span style={{ fontSize: 13, color: 'oklch(0.75 0.010 240)' }}>{doneTasks} of {job.tasks.length} tasks complete</span>
          <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 700, color: 'oklch(0.78 0.18 80)' }}>{progress}%</span>
        </div>
        <ProgressBar value={progress} color="oklch(0.78 0.18 80)" />
      </div>

      <div style={{ display: 'flex', gap: 8 }}>
        <button onClick={e => { e.stopPropagation(); toast.info("Opening Maps..."); }} style={{
          background: 'oklch(0.65 0.18 250 / 0.15)', border: '1px solid oklch(0.65 0.18 250 / 0.3)',
          color: 'oklch(0.65 0.18 250)', borderRadius: 7, padding: '7px 14px',
          fontSize: 12, fontWeight: 600, cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 6,
        }}>
          <Navigation size={13} /> Navigate
        </button>
        <button onClick={onSelect} style={{
          flex: 1, background: 'oklch(0.78 0.18 80)', border: 'none',
          color: 'oklch(0.09 0.008 240)', borderRadius: 7, padding: '7px 14px',
          fontSize: 12, fontWeight: 700, cursor: 'pointer',
          fontFamily: "'Space Grotesk', sans-serif",
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
        }}>
          Open Job <ChevronRight size={14} />
        </button>
      </div>
    </div>
  );
}

function JobCard({ job, onSelect }: { job: Job; onSelect: () => void }) {
  const { properties } = useApp();
  const prop = properties.find(p => p.id === job.property_id);
  const progress = Math.round((job.tasks.filter(t => t.done).length / job.tasks.length) * 100);

  return (
    <div onClick={onSelect} className="ff-card" style={{ padding: '16px', cursor: 'pointer' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 2 }}>{job.title}</div>
          <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><MapPin size={10} /> {prop?.name}</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Clock size={10} /> {job.scheduled}</span>
          </div>
        </div>
        <StatusBadge status={job.status} />
        <span style={{ color: 'oklch(0.65 0.18 155)', fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 700 }}>
          ${job.total.toLocaleString()}
        </span>
        <ChevronRight size={14} color="oklch(0.40 0.010 240)" />
      </div>
      {job.status === "IN_PROGRESS" && (
        <div style={{ marginTop: 10 }}>
          <ProgressBar value={progress} />
        </div>
      )}
    </div>
  );
}

function JobDetailView({ jobId, onBack }: { jobId: string; onBack: () => void }) {
  const { jobs, properties, updateJobTask, updateJobStatus, addAuditLog, user } = useApp();
  const job = jobs.find(j => j.id === jobId);
  const prop = properties.find(p => p.id === job?.property_id);

  if (!job) return null;

  const doneTasks = job.tasks.filter(t => t.done).length;
  const progress = Math.round((doneTasks / job.tasks.length) * 100);
  const allDone = job.tasks.every(t => t.done);

  const handleTaskToggle = (taskId: string, done: boolean) => {
    updateJobTask(jobId, taskId, done);
    const task = job.tasks.find(t => t.id === taskId);
    if (done && user) {
      addAuditLog(user.name, "TASK_COMPLETED", jobId, `Task completed: ${task?.label}`, user.role);
      toast.success(`✓ ${task?.label}`);
    }
  };

  const handleCompleteJob = () => {
    if (!allDone) {
      toast.error("Complete all tasks before marking job done");
      return;
    }
    updateJobStatus(jobId, "COMPLETED");
    if (user) {
      addAuditLog(user.name, "JOB_COMPLETED", jobId, `Job completed: ${job.title} at ${prop?.name}`, user.role);
    }
    toast.success("Job marked complete!");
    onBack();
  };

  return (
    <div style={{ padding: '24px', maxWidth: 640, margin: '0 auto', color: 'oklch(0.94 0.005 240)' }} className="animate-fade-up">
      <button onClick={onBack} style={{
        background: 'none', border: 'none', color: 'oklch(0.60 0.015 240)',
        cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
        fontSize: 13, marginBottom: 20, padding: 0,
      }}>
        <ArrowLeft size={14} /> Back to Jobs
      </button>

      {/* Job Header */}
      <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, padding: '20px', marginBottom: 20 }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 12 }}>
          <div>
            <h2 style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 20, letterSpacing: '-0.02em', marginBottom: 4 }}>
              {job.title}
            </h2>
            <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 13, display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
              <MapPin size={13} /> {prop?.address}
            </div>
            <div style={{ color: 'oklch(0.60 0.015 240)', fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
              <Clock size={13} /> {job.scheduled}
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <StatusBadge status={job.status} />
            <div style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 20, fontWeight: 700, color: 'oklch(0.65 0.18 155)', marginTop: 8 }}>
              ${job.total.toLocaleString()}
            </div>
          </div>
        </div>

        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
            <span style={{ fontSize: 13, color: 'oklch(0.75 0.010 240)' }}>{doneTasks} of {job.tasks.length} tasks</span>
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 14, fontWeight: 700, color: progress === 100 ? 'oklch(0.65 0.18 155)' : 'oklch(0.72 0.18 50)' }}>{progress}%</span>
          </div>
          <ProgressBar value={progress} />
        </div>

        <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
          <button onClick={() => toast.info("Opening navigation...")} style={{
            flex: 1, background: 'oklch(0.65 0.18 250 / 0.15)', border: '1px solid oklch(0.65 0.18 250 / 0.3)',
            color: 'oklch(0.65 0.18 250)', borderRadius: 8, padding: '10px',
            fontSize: 13, fontWeight: 600, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}>
            <Navigation size={14} /> Navigate
          </button>
          <button onClick={() => toast.info("Calling property manager...")} style={{
            background: 'oklch(0.15 0.012 240)', border: '1px solid oklch(0.20 0.012 240)',
            color: 'oklch(0.60 0.015 240)', borderRadius: 8, padding: '10px 16px',
            fontSize: 13, cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 6,
          }}>
            <Phone size={14} />
          </button>
        </div>
      </div>

      {/* Task Checklist */}
      <div style={{ marginBottom: 20 }}>
        <SectionHeader title="Task Checklist" subtitle="Tap to mark complete" />
        <div style={{ background: 'oklch(0.12 0.01 240)', border: '1px solid oklch(0.20 0.012 240)', borderRadius: 12, overflow: 'hidden' }}>
          {job.tasks.map((task: JobTask, i: number, arr: JobTask[]) => (
            <div
              key={task.id}
              onClick={() => job.status !== "COMPLETED" && handleTaskToggle(task.id, !task.done)}
              style={{
                padding: '16px 20px',
                borderBottom: i < arr.length - 1 ? '1px solid oklch(0.20 0.012 240)' : 'none',
                display: 'flex', alignItems: 'center', gap: 14,
                cursor: job.status !== "COMPLETED" ? 'pointer' : 'default',
                background: task.done ? 'oklch(0.65 0.18 155 / 0.05)' : 'transparent',
                transition: 'background 0.15s',
              }}
            >
              <div style={{
                width: 24, height: 24, borderRadius: 6, flexShrink: 0,
                background: task.done ? 'oklch(0.65 0.18 155)' : 'transparent',
                border: task.done ? 'none' : '2px solid oklch(0.26 0.015 240)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'all 0.15s',
              }}>
                {task.done && (
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                    <path d="M2 6l3 3 5-5" stroke="oklch(0.09 0.008 240)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </div>

              <div style={{ flex: 1 }}>
                <div style={{
                  fontSize: 14, fontWeight: 500,
                  color: task.done ? 'oklch(0.60 0.015 240)' : 'oklch(0.94 0.005 240)',
                  textDecoration: task.done ? 'line-through' : 'none',
                }}>
                  {task.label}
                </div>
                {task.photo && (
                  <div style={{ fontSize: 11, color: 'oklch(0.72 0.18 50)', display: 'flex', alignItems: 'center', gap: 4, marginTop: 2 }}>
                    <Camera size={10} /> Photo required
                  </div>
                )}
              </div>

              {task.photo && !task.done && (
                <button onClick={e => { e.stopPropagation(); toast.success("Photo captured!"); }} style={{
                  background: 'oklch(0.72 0.18 50 / 0.15)',
                  border: '1px solid oklch(0.72 0.18 50 / 0.3)',
                  color: 'oklch(0.72 0.18 50)',
                  borderRadius: 6, padding: '5px 10px', cursor: 'pointer',
                  fontSize: 11, display: 'flex', alignItems: 'center', gap: 4,
                }}>
                  <Camera size={12} /> Capture
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {job.status !== "COMPLETED" && (
        <button onClick={handleCompleteJob} style={{
          width: '100%', padding: '16px',
          background: allDone ? 'oklch(0.65 0.18 155)' : 'oklch(0.15 0.012 240)',
          border: allDone ? 'none' : '1px solid oklch(0.20 0.012 240)',
          color: allDone ? 'oklch(0.09 0.008 240)' : 'oklch(0.60 0.015 240)',
          borderRadius: 10, cursor: allDone ? 'pointer' : 'not-allowed',
          fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700, fontSize: 15,
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          transition: 'all 0.15s',
        }}>
          <CheckCircle size={18} />
          {allDone ? "Mark Job Complete" : `${job.tasks.filter(t => !t.done).length} tasks remaining`}
        </button>
      )}

      {job.status === "COMPLETED" && (
        <div style={{
          background: 'oklch(0.65 0.18 155 / 0.1)',
          border: '1px solid oklch(0.65 0.18 155 / 0.3)',
          borderRadius: 10, padding: '16px',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          color: 'oklch(0.65 0.18 155)', fontWeight: 600, fontSize: 14,
        }}>
          <CheckCircle size={18} /> Job Completed
        </div>
      )}
    </div>
  );
}
