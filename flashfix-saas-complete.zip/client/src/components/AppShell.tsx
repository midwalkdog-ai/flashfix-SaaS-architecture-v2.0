/**
 * FlashFix AppShell — Persistent sidebar layout for all dashboard portals
 * Design: Industrial Command Center — dark sidebar, orange accent
 */
import { ReactNode, useState } from "react";
import { useLocation } from "wouter";
import { useApp } from "@/contexts/AppContext";
import {
  Zap, LayoutDashboard, Building, ClipboardList, DollarSign,
  Users, FileText, Settings, LogOut, Bell, Menu, X,
  Hammer, Camera, BarChart3, Shield, ChevronRight
} from "lucide-react";
import { toast } from "sonner";

interface NavItem {
  id: string;
  label: string;
  icon: ReactNode;
  roles: string[];
  badge?: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: "dashboard", label: "Dashboard", icon: <LayoutDashboard size={16} />, roles: ["ADMIN", "PROPERTY_MANAGER", "CONTRACTOR"] },
  { id: "properties", label: "Properties", icon: <Building size={16} />, roles: ["ADMIN", "PROPERTY_MANAGER"] },
  { id: "jobs", label: "Jobs", icon: <ClipboardList size={16} />, roles: ["ADMIN", "PROPERTY_MANAGER", "CONTRACTOR"] },
  { id: "quote_builder", label: "Quote Builder", icon: <DollarSign size={16} />, roles: ["ADMIN", "PROPERTY_MANAGER"] },
  { id: "reports", label: "Reports", icon: <BarChart3 size={16} />, roles: ["ADMIN", "PROPERTY_MANAGER"] },
  { id: "pricing", label: "Pricing Catalog", icon: <FileText size={16} />, roles: ["ADMIN"] },
  { id: "users", label: "Users", icon: <Users size={16} />, roles: ["ADMIN"] },
  { id: "audit_log", label: "Audit Log", icon: <Shield size={16} />, roles: ["ADMIN"] },
];

export default function AppShell({ children }: { children: ReactNode }) {
  const { user, logout, currentView, setCurrentView } = useApp();
  const [, navigate] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const visibleNav = NAV_ITEMS.filter(item => user && item.roles.includes(user.role));
  const roleColor = {
    ADMIN: "oklch(0.72 0.18 50)",
    PROPERTY_MANAGER: "oklch(0.65 0.18 250)",
    CONTRACTOR: "oklch(0.65 0.18 155)",
  }[user?.role || "ADMIN"];

  const handleLogout = () => {
    logout();
    navigate("/");
    toast.info("Signed out successfully");
  };

  const SidebarContent = () => (
    <div style={{
      width: 220, height: '100vh', position: 'fixed',
      background: 'oklch(0.10 0.009 240)',
      borderRight: '1px solid oklch(0.20 0.012 240)',
      display: 'flex', flexDirection: 'column',
      zIndex: 50,
      fontFamily: "'DM Sans', system-ui, sans-serif",
    }}>
      {/* Logo */}
      <div style={{
        padding: '16px 16px',
        borderBottom: '1px solid oklch(0.20 0.012 240)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{
            width: 28, height: 28, borderRadius: 7,
            background: 'oklch(0.72 0.18 50)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <Zap size={15} color="oklch(0.09 0.008 240)" strokeWidth={2.5} />
          </div>
          <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 16, letterSpacing: '-0.03em', color: 'oklch(0.94 0.005 240)' }}>
            Flash<span style={{ color: 'oklch(0.72 0.18 50)' }}>Fix</span>
          </span>
        </div>
        <button onClick={() => setSidebarOpen(false)} style={{
          background: 'none', border: 'none', color: 'oklch(0.60 0.015 240)',
          cursor: 'pointer', display: 'none', padding: 4,
        }} className="flex lg:hidden">
          <X size={16} />
        </button>
      </div>

      {/* User info */}
      <div style={{
        padding: '12px 16px',
        borderBottom: '1px solid oklch(0.20 0.012 240)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 32, height: 32, borderRadius: '50%',
            background: `${roleColor.replace(')', ' / 0.2)')}`,
            border: `2px solid ${roleColor.replace(')', ' / 0.4)')}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: "'JetBrains Mono', monospace", fontSize: 11, fontWeight: 700,
            color: roleColor,
          }}>
            {user?.avatar}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontWeight: 600, fontSize: 13, color: 'oklch(0.94 0.005 240)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {user?.name}
            </div>
            <div style={{
              fontSize: 10, fontFamily: "'JetBrains Mono', monospace",
              color: roleColor, textTransform: 'uppercase', letterSpacing: '0.06em',
            }}>
              {user?.role?.replace("_", " ")}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav style={{ flex: 1, padding: '12px 10px', overflowY: 'auto' }}>
        <div style={{ fontSize: 10, fontFamily: "'JetBrains Mono', monospace", color: 'oklch(0.40 0.010 240)', letterSpacing: '0.1em', textTransform: 'uppercase', padding: '4px 6px', marginBottom: 4 }}>
          Navigation
        </div>
        {visibleNav.map(item => {
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => { setCurrentView(item.id); setSidebarOpen(false); }}
              style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '7px 10px', borderRadius: 7,
                width: '100%', textAlign: 'left',
                background: isActive ? 'oklch(0.72 0.18 50 / 0.12)' : 'transparent',
                border: isActive ? '1px solid oklch(0.72 0.18 50 / 0.2)' : '1px solid transparent',
                color: isActive ? 'oklch(0.72 0.18 50)' : 'oklch(0.60 0.015 240)',
                fontSize: 13, fontWeight: isActive ? 600 : 400,
                cursor: 'pointer', transition: 'all 0.12s ease',
                marginBottom: 2,
              }}
              onMouseEnter={e => {
                if (!isActive) {
                  e.currentTarget.style.background = 'oklch(0.15 0.012 240)';
                  e.currentTarget.style.color = 'oklch(0.94 0.005 240)';
                }
              }}
              onMouseLeave={e => {
                if (!isActive) {
                  e.currentTarget.style.background = 'transparent';
                  e.currentTarget.style.color = 'oklch(0.60 0.015 240)';
                }
              }}
            >
              <span style={{ opacity: isActive ? 1 : 0.7 }}>{item.icon}</span>
              {item.label}
              {item.badge && (
                <span style={{
                  marginLeft: 'auto',
                  background: 'oklch(0.62 0.22 25 / 0.2)',
                  color: 'oklch(0.62 0.22 25)',
                  fontSize: 10, fontWeight: 700,
                  padding: '1px 6px', borderRadius: 3,
                  fontFamily: "'JetBrains Mono', monospace",
                }}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom actions */}
      <div style={{ padding: '10px', borderTop: '1px solid oklch(0.20 0.012 240)' }}>
        <button onClick={() => toast.info("Settings coming soon")} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          padding: '7px 10px', borderRadius: 7,
          width: '100%', textAlign: 'left',
          background: 'transparent', border: '1px solid transparent',
          color: 'oklch(0.60 0.015 240)', fontSize: 13, cursor: 'pointer',
          marginBottom: 4, transition: 'all 0.12s',
        }}
          onMouseEnter={e => { e.currentTarget.style.background = 'oklch(0.15 0.012 240)'; e.currentTarget.style.color = 'oklch(0.94 0.005 240)'; }}
          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'oklch(0.60 0.015 240)'; }}
        >
          <Settings size={16} /> Settings
        </button>
        <button onClick={handleLogout} style={{
          display: 'flex', alignItems: 'center', gap: 8,
          padding: '7px 10px', borderRadius: 7,
          width: '100%', textAlign: 'left',
          background: 'transparent', border: '1px solid transparent',
          color: 'oklch(0.60 0.015 240)', fontSize: 13, cursor: 'pointer',
          transition: 'all 0.12s',
        }}
          onMouseEnter={e => { e.currentTarget.style.background = 'oklch(0.62 0.22 25 / 0.1)'; e.currentTarget.style.color = 'oklch(0.62 0.22 25)'; }}
          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'oklch(0.60 0.015 240)'; }}
        >
          <LogOut size={16} /> Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'oklch(0.09 0.008 240)', fontFamily: "'DM Sans', system-ui, sans-serif" }}>
      {/* Desktop sidebar */}
      <div className="hidden lg:block" style={{ width: 220, flexShrink: 0 }}>
        <SidebarContent />
      </div>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 49 }}>
          <div onClick={() => setSidebarOpen(false)} style={{ position: 'absolute', inset: 0, background: 'oklch(0 0 0 / 0.6)' }} />
          <SidebarContent />
        </div>
      )}

      {/* Main content */}
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        {/* Mobile topbar */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '12px 16px',
          background: 'oklch(0.10 0.009 240)',
          borderBottom: '1px solid oklch(0.20 0.012 240)',
        }} className="flex lg:hidden">
          <button onClick={() => setSidebarOpen(true)} style={{
            background: 'none', border: 'none', color: 'oklch(0.94 0.005 240)', cursor: 'pointer',
          }}>
            <Menu size={20} />
          </button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 22, height: 22, borderRadius: 5, background: 'oklch(0.72 0.18 50)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Zap size={12} color="oklch(0.09 0.008 240)" strokeWidth={2.5} />
            </div>
            <span style={{ fontFamily: "'Space Grotesk', sans-serif", fontWeight: 800, fontSize: 14, letterSpacing: '-0.03em', color: 'oklch(0.94 0.005 240)' }}>
              Flash<span style={{ color: 'oklch(0.72 0.18 50)' }}>Fix</span>
            </span>
          </div>
          <button onClick={() => toast.info("Notifications coming soon")} style={{
            background: 'none', border: 'none', color: 'oklch(0.60 0.015 240)', cursor: 'pointer',
          }}>
            <Bell size={18} />
          </button>
        </div>

        {/* Page content */}
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {children}
        </div>
      </div>
    </div>
  );
}
