import { createContext, useContext, useReducer, useState, useCallback, ReactNode } from "react";

// ============================================================
// TYPES
// ============================================================
export type UserRole = "ADMIN" | "PROPERTY_MANAGER" | "CONTRACTOR";
export type JobStatus = "SCHEDULED" | "IN_PROGRESS" | "COMPLETED" | "CANCELLED";
export type PropertyStatus = "NEEDS_TURNOVER" | "IN_PROGRESS" | "RENT_READY" | "OCCUPIED";
export type Priority = "LOW" | "NORMAL" | "HIGH" | "URGENT";

export interface User {
  id: string;
  email: string;
  role: UserRole;
  name: string;
  avatar: string;
}

export interface Property {
  id: string;
  name: string;
  address: string;
  status: PropertyStatus;
  pm_id: string;
  score: number;
  notes?: string;
}

export interface JobTask {
  id: string;
  label: string;
  done: boolean;
  photo: boolean;
  requires_photo?: boolean;
}

export interface Job {
  id: string;
  property_id: string;
  contractor_id: string;
  title: string;
  status: JobStatus;
  priority: Priority;
  scheduled: string;
  total: number;
  tasks: JobTask[];
  description?: string;
}

export interface AuditLog {
  id: string;
  ts: string;
  actor: string;
  action: string;
  entity: string;
  detail: string;
  role: UserRole;
}

export interface Service {
  name: string;
  category: string;
  price: number;
  unit: string;
  duration: number;
}

export interface ToastItem {
  id: number;
  msg: string;
  type: "success" | "error" | "info" | "warn";
}

// ============================================================
// MOCK DATA
// ============================================================
export const MOCK_USERS: Record<string, User> = {
  admin: { id: "usr_01", email: "admin@flashfix.io", role: "ADMIN", name: "Jordan Blake", avatar: "JB" },
  pm: { id: "usr_02", email: "sarah@propertyco.com", role: "PROPERTY_MANAGER", name: "Sarah Chen", avatar: "SC" },
  contractor: { id: "usr_03", email: "mike@flashfix.io", role: "CONTRACTOR", name: "Mike Torres", avatar: "MT" },
};

export const MOCK_PROPERTIES: Property[] = [
  { id: "prop_01", name: "Riverdale Arms Unit 4B", address: "412 Riverdale Dr, Springfield MO 65806", status: "NEEDS_TURNOVER", pm_id: "usr_02", score: 78 },
  { id: "prop_02", name: "Oak Grove #12", address: "88 Oak Grove Ln, Springfield MO 65804", status: "IN_PROGRESS", pm_id: "usr_02", score: 92 },
  { id: "prop_03", name: "Westfield Loft 3A", address: "200 W Commercial St, Springfield MO 65803", status: "RENT_READY", pm_id: "usr_02", score: 98 },
  { id: "prop_04", name: "Cedar Bluff #7", address: "1440 S Cedar Ave, Springfield MO 65802", status: "NEEDS_TURNOVER", pm_id: "usr_02", score: 61 },
  { id: "prop_05", name: "Maple Heights 2C", address: "330 N Maple Ave, Springfield MO 65806", status: "OCCUPIED", pm_id: "usr_02", score: 85 },
  { id: "prop_06", name: "Sunset Ridge #9", address: "770 Sunset Dr, Springfield MO 65803", status: "RENT_READY", pm_id: "usr_02", score: 95 },
];

export const MOCK_JOBS: Job[] = [
  {
    id: "job_001", property_id: "prop_01", contractor_id: "usr_03",
    title: "Full Turnover Reset", status: "IN_PROGRESS", priority: "HIGH",
    scheduled: "2026-03-24", total: 1499,
    tasks: [
      { id: "t1", label: "Drywall patch bedroom", done: true, photo: true },
      { id: "t2", label: "Paint living room", done: true, photo: false },
      { id: "t3", label: "Replace faucet bathroom", done: false, photo: false },
      { id: "t4", label: "Lock rekey front door", done: false, photo: false },
      { id: "t5", label: "Smoke detector test", done: false, photo: false },
    ]
  },
  {
    id: "job_002", property_id: "prop_04", contractor_id: "usr_03",
    title: "Standard Turnover Package", status: "SCHEDULED", priority: "NORMAL",
    scheduled: "2026-03-25", total: 899,
    tasks: [
      { id: "t6", label: "Full safety inspection", done: false, photo: false },
      { id: "t7", label: "Caulking & grout repair", done: false, photo: false },
      { id: "t8", label: "Minor plumbing fixes", done: false, photo: false },
    ]
  },
  {
    id: "job_003", property_id: "prop_02", contractor_id: "usr_03",
    title: "Appliance Installation", status: "COMPLETED", priority: "NORMAL",
    scheduled: "2026-03-22", total: 375,
    tasks: [
      { id: "t9", label: "Washer/Dryer install", done: true, photo: true },
      { id: "t10", label: "Dishwasher install", done: true, photo: true },
    ]
  },
  {
    id: "job_004", property_id: "prop_06", contractor_id: "usr_03",
    title: "Basic Turnover Refresh", status: "SCHEDULED", priority: "LOW",
    scheduled: "2026-03-26", total: 499,
    tasks: [
      { id: "t11", label: "Deep clean all rooms", done: false, photo: false },
      { id: "t12", label: "Touch-up paint", done: false, photo: false },
      { id: "t13", label: "Replace light bulbs", done: false, photo: false },
    ]
  },
];

export const MOCK_AUDIT_LOGS: AuditLog[] = [
  { id: "log_01", ts: "2026-03-23T14:32:00Z", actor: "Mike Torres", action: "TASK_COMPLETED", entity: "job_001", detail: "Drywall patch bedroom — marked complete", role: "CONTRACTOR" },
  { id: "log_02", ts: "2026-03-23T11:15:00Z", actor: "Sarah Chen", action: "QUOTE_APPROVED", entity: "job_002", detail: "Quote $899 approved for Cedar Bluff #7", role: "PROPERTY_MANAGER" },
  { id: "log_03", ts: "2026-03-22T16:45:00Z", actor: "Jordan Blake", action: "USER_INVITED", entity: "usr_03", detail: "Contractor Mike Torres invited to platform", role: "ADMIN" },
  { id: "log_04", ts: "2026-03-22T09:00:00Z", actor: "Mike Torres", action: "JOB_COMPLETED", entity: "job_003", detail: "Appliance Installation marked COMPLETE — Oak Grove #12", role: "CONTRACTOR" },
  { id: "log_05", ts: "2026-03-21T15:30:00Z", actor: "Sarah Chen", action: "JOB_CREATED", entity: "job_004", detail: "New job created: Basic Turnover Refresh — Sunset Ridge #9", role: "PROPERTY_MANAGER" },
];

export const SERVICES: Service[] = [
  { name: "Basic Turnover Refresh", category: "Turnover Package", price: 499, unit: "Flat Rate", duration: 120 },
  { name: "Standard Turnover Package", category: "Turnover Package", price: 899, unit: "Flat Rate", duration: 180 },
  { name: "Full Turnover Reset", category: "Turnover Package", price: 1499, unit: "Flat Rate", duration: 240 },
  { name: "Hourly Handyman Labor", category: "Handyman / Repair", price: 85, unit: "Per Hour", duration: 60 },
  { name: "Door Adjustment / Repair", category: "Handyman / Repair", price: 125, unit: "Each", duration: 60 },
  { name: "Drywall Patch (Small Area)", category: "Handyman / Repair", price: 45, unit: "Each", duration: 30 },
  { name: "TV Mount Installation", category: "Handyman / Repair", price: 150, unit: "Each", duration: 60 },
  { name: "Room Paint Package", category: "Painting", price: 299, unit: "Per Room", duration: 120 },
  { name: "Whole Apartment Paint (1/1)", category: "Painting", price: 1100, unit: "Flat Rate", duration: 360 },
  { name: "Vinyl Plank Flooring Install", category: "Flooring", price: 2.75, unit: "Per Sq Ft", duration: 0 },
  { name: "Tile Repair (Small Area)", category: "Flooring", price: 175, unit: "Minimum", duration: 90 },
  { name: "Faucet Replacement", category: "Plumbing", price: 150, unit: "Each", duration: 60 },
  { name: "Toilet Replacement", category: "Plumbing", price: 175, unit: "Each", duration: 75 },
  { name: "Clog Clearing", category: "Plumbing", price: 125, unit: "Each", duration: 45 },
  { name: "Ceiling Fan Installation", category: "Electrical", price: 175, unit: "Each", duration: 75 },
  { name: "Light Fixture Installation", category: "Electrical", price: 125, unit: "Each", duration: 60 },
  { name: "Outlet or Switch Replacement", category: "Electrical", price: 45, unit: "Each", duration: 30 },
  { name: "Washer/Dryer Installation", category: "Appliance Services", price: 150, unit: "Set", duration: 90 },
  { name: "Dishwasher Installation", category: "Appliance Services", price: 225, unit: "Each", duration: 75 },
  { name: "Trash-Out (Pickup Load)", category: "Exterior / Cleanup", price: 150, unit: "Per Load", duration: 90 },
  { name: "Pressure Washing", category: "Exterior / Cleanup", price: 199, unit: "Flat Rate", duration: 120 },
  { name: "Lock Change / Rekey", category: "Property Mgmt Support", price: 125, unit: "Each", duration: 45 },
  { name: "Smoke Detector Replacement", category: "Property Mgmt Support", price: 35, unit: "Each", duration: 15 },
  { name: "Emergency Same-Day Fee", category: "Property Mgmt Support", price: 150, unit: "Each", duration: 0 },
];

// ============================================================
// CONTEXT
// ============================================================
interface AppContextType {
  user: User | null;
  login: (role: keyof typeof MOCK_USERS) => void;
  logout: () => void;
  jobs: Job[];
  properties: Property[];
  auditLogs: AuditLog[];
  updateJobTask: (jobId: string, taskId: string, done: boolean) => void;
  updateJobStatus: (jobId: string, status: JobStatus) => void;
  addAuditLog: (actor: string, action: string, entity: string, detail: string, role: UserRole) => void;
  addJob: (job: Job) => void;
  currentView: string;
  setCurrentView: (view: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [jobs, setJobs] = useState<Job[]>(MOCK_JOBS);
  const [properties] = useState<Property[]>(MOCK_PROPERTIES);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(MOCK_AUDIT_LOGS);
  const [currentView, setCurrentView] = useState("dashboard");

  const addAuditLog = useCallback((actor: string, action: string, entity: string, detail: string, role: UserRole) => {
    const log: AuditLog = {
      id: `log_${Date.now()}`,
      ts: new Date().toISOString(),
      actor, action, entity, detail, role
    };
    setAuditLogs(prev => [log, ...prev]);
  }, []);

  const updateJobTask = useCallback((jobId: string, taskId: string, done: boolean) => {
    setJobs(prev => prev.map(j =>
      j.id === jobId
        ? { ...j, tasks: j.tasks.map(t => t.id === taskId ? { ...t, done } : t) }
        : j
    ));
  }, []);

  const updateJobStatus = useCallback((jobId: string, status: JobStatus) => {
    setJobs(prev => prev.map(j => j.id === jobId ? { ...j, status } : j));
  }, []);

  const addJob = useCallback((job: Job) => {
    setJobs(prev => [job, ...prev]);
  }, []);

  const login = useCallback((role: keyof typeof MOCK_USERS) => {
    const u = MOCK_USERS[role];
    setUser(u);
    setCurrentView("dashboard");
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setCurrentView("dashboard");
  }, []);

  return (
    <AppContext.Provider value={{
      user, login, logout,
      jobs, properties, auditLogs,
      updateJobTask, updateJobStatus, addAuditLog, addJob,
      currentView, setCurrentView,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
